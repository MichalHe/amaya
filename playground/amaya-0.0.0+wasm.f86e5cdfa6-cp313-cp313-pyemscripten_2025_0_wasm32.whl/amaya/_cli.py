#!/usr/bin/env python3
r'''
 ______     __    __     ______     __  __     ______
/\  __ \   /\ "-./  \   /\  __ \   /\ \_\ \   /\  __ \
\ \  __ \  \ \ \-./\ \  \ \  __ \  \ \____ \  \ \  __ \
 \ \_\ \_\  \ \_\ \ \_\  \ \_\ \_\  \/\_____\  \ \_\ \_\
  \/_/\/_/   \/_/  \/_/   \/_/\/_/   \/_____/   \/_/\/_/

Amaya v2.0.
Amaya is an experimental, automata based LIA SMT solver.

The solver accepts input formulae written in the SMTlib (v2) language.
Currently, there are two backends available to be used when evaluating the
given formula (controlled via the `--backend` option):
    - native - symbols that belong to a transition are stored in a semi-
               compressed form and all the automaton operations perform
               iteration of some kind over these transitions (the backend
               is rather slow)
    - MTBDD - transition symbols are stored using MTBDDs (compact
              representation). The operations manipulating automatons are much
              faster, however the backend support is relatively fresh, so there
              might still be bugs in the evaluation).
'''
import argparse as ap
from collections.abc import Iterable
import functools
import contextlib
from enum import Enum
import json
import os
import logging
import sys
from typing import Callable, List, Dict, Optional, Tuple, cast
from dataclasses import dataclass
import time
import statistics

from amaya import logger, shard_logger
from amaya import solver_core as core
from amaya import parse
from amaya.config import (
    ASSERTION_OPTIMIZER_MODES,
    BackendType,
    MinimizationAlgorithms,
    solver_config,
    SolutionDomain,
)
from amaya.converters import generate_optimization_problem, write_ast_in_lash, write_ast_in_smt2
from amaya.preprocessing import preprocess_ast
from amaya.preprocessing.eval import NonlinearArithmeticError, VarInfo, convert_ast_into_evaluable_form
from amaya.preprocessing.pipeline import Pipeline_Report
from amaya.relations_structures import AST_NaryNode, AST_Node, AST_Node_Names, ASTp_Node, FunctionSymbol, Var, VariableType
from amaya.stats import RunStats, StatPoint
from amaya.tokenize import tokenize
import amaya.utils as utils


class RunnerMode(Enum):
    GET_SAT = 'get-sat'
    BENCHMARK = 'benchmark'
    CONVERT_FORMULA = 'convert'


@dataclass
class BenchmarkStat:
    name: str
    path: str
    runtimes_ns: List[int]
    failed: bool
    pipeline_report: Optional[Pipeline_Report] = None
    """The last run's `Pipeline_Report`, if `optimization_pipeline.enabled` (see plan step 8)."""

    @property
    def avg_runtime_ns(self) -> Optional[float]:
        if not self.runtimes_ns:
            return None
        return sum(self.runtimes_ns) / len(self.runtimes_ns)

    def as_dict(self) -> Dict:
        result = {
            'name': self.name,
            'path': self.path,
            'runtimes_ns': self.runtimes_ns,
            'avg_runtime_ns': self.avg_runtime_ns,
            'failed': self.failed,
        }
        if self.pipeline_report is not None:
            result['pipeline_report'] = {
                'rounds': self.pipeline_report.rounds,
                'termination': self.pipeline_report.termination,
                'input_size': self.pipeline_report.input_size,
                'output_size': self.pipeline_report.output_size,
                'pass_sequence': self.pipeline_report.pass_sequence,
                'pass_stats': {
                    name: {
                        'invocations': stat.invocations,
                        'productive': stat.productive,
                        'discarded_for_growth': stat.discarded_for_growth,
                        'total_time_ns': stat.total_time_ns,
                        'nodes_removed': stat.nodes_removed,
                    }
                    for name, stat in self.pipeline_report.pass_stats.items()
                },
            }
        return result


argparser = ap.ArgumentParser(description=__doc__, formatter_class=ap.RawTextHelpFormatter)

argparser.add_argument('--backend',
                       choices=['MTBDD', 'native'],
                       default='native',
                       help='Selects the backend used in the automatons to store the transition function.')

argparser.add_argument('--verbose',
                       action='store_true',
                       default=False,
                       help='Toggles the verbose output (logging level >= INFO).')

argparser.add_argument('--debug',
                       action='store_true',
                       default=False,
                       help='Enables debug output  (logging level >= DEBUG).')

argparser.add_argument('--fast',
                       action='store_true',
                       default=False,
                       help='Enable MTBDD backend and Hopcroft\'s minimization.')

argparser.add_argument('--astp-cse',
                       action='store_true',
                       dest='astp_cse',
                       default=False,
                       help=('(EXPERIMENTAL) Cache automata built for subformulae keyed by a De Bruijn/slot-normalised\n'
                             'encoding, so that alpha-equivalent subformulae (e.g. two differently-named quantified\n'
                             'subtrees with the same shape) reuse one automaton instead of being constructed again.\n'
                             'Requires -m MTBDD; a no-op (falls back to the ordinary evaluation) on any other backend.\n'
                             'Does not change the result on any input - see DEBRUJIN_CSE.md.'))

argparser.add_argument('--use-toplevel-sat',
                       action='store_true',
                       dest='use_toplevel_sat',
                       default=False,
                       help=('(EXPERIMENTAL) Decide the formula\'s free Bool variables with a CDCL SAT solver and hand\n'
                             'only the residual LIA formulae to the automata engine, blocking an assignment and asking\n'
                             'for the next one whenever its residual turns out unsatisfiable. Intended for\n'
                             'Boolean-structure-heavy inputs; formulae without free Bool variables fall through to the\n'
                             'ordinary evaluation. Implies --astp-cse (the loop relies on the automaton cache to reuse\n'
                             'work across iterations), so -m MTBDD is strongly recommended. Cannot be combined with\n'
                             '--shard. Requires python-sat. See SAT_TOP_LEVEL.md.'))

argparser.add_argument('--toplevel-sat-exact-blocking',
                       action='store_true',
                       dest='toplevel_sat_exact_blocking',
                       default=False,
                       help=('(EXPERIMENTAL) Only meaningful together with --use-toplevel-sat: block a refuted\n'
                             'Boolean assignment exactly, instead of blocking every assignment that agrees with it\n'
                             'on the variables the refuted residual actually depended on. Strictly weaker pruning;\n'
                             'exists to measure what the generalized blocking clauses buy. See SAT_TOP_LEVEL.md.'))

argparser.add_argument('--use-dpllt-automata',
                       action='store_true',
                       dest='use_dpllt_automata',
                       default=False,
                       help=('(EXPERIMENTAL) Split the formula into a general part and a part whose quantifiers are\n'
                             'all positive-existential, abstract the literals of the latter into a monotone Boolean\n'
                             'formula, and enumerate its minimal implicants with a SAT solver: each implicant is\n'
                             'asserted as a conjunction of literals, evaluated with automata, and intersected with\n'
                             'the automaton for the general part, which is built once. Formulae with no such part,\n'
                             'or whose such part contains no disjunction, fall through to the ordinary evaluation.\n'
                             'Implies --astp-cse; --backend MTBDD is required for either automaton cache to be\n'
                             'in play.\n'
                             'Cannot be combined with --shard or --use-toplevel-sat. Requires python-sat.\n'
                             'See docs/DPLLT_WITH_AUTOMATA.md.'))

argparser.add_argument('--dpllt-assertion-optimizer',
                       choices=ASSERTION_OPTIMIZER_MODES,
                       dest='dpllt_assertion_optimizer',
                       default=None,
                       help=('(EXPERIMENTAL) Which passes the per-iteration assertion is optimized with.\n'
                             '"none" hands it to the evaluator unoptimized; "restricted" (the default) filters the\n'
                             'registry to the passes classified as preserving the assertion\'s solution set over its\n'
                             'free variables - that classification has not been performed, so the set is empty and\n'
                             'the mode behaves as "none"; "full" runs the whole enabled registry and is KNOWN TO BE\n'
                             'UNSOUND here, since the pipeline contains passes that only preserve satisfiability of\n'
                             'the whole formula. See docs/DPLLT_WITH_AUTOMATA.md, section 7.2.'))

argparser.add_argument('--dpllt-no-implicant-minimization',
                       action='store_true',
                       dest='dpllt_no_implicant_minimization',
                       default=False,
                       help=('(EXPERIMENTAL) Assert every literal the SAT solver sets to true, instead of reducing\n'
                             'the set to a minimal implicant of the abstraction first. Exists to measure what the\n'
                             'minimization buys.'))

argparser.add_argument('--dpllt-no-bounds-refutation',
                       action='store_true',
                       dest='dpllt_no_bounds_refutation',
                       default=False,
                       help=('(EXPERIMENTAL) Hand every asserted literal set to the automata engine, instead of\n'
                             'first intersecting the unit bounds of its literals and refuting the assertion when\n'
                             'they clash. With the check on (the default), the clashing pair is blocked instead of\n'
                             'the whole implicant, which removes every literal set containing that pair. Exists to\n'
                             'measure what the check buys.'))

argparser.add_argument('--dpllt-bound-propagation-rounds',
                       type=int,
                       dest='dpllt_bound_propagation_rounds',
                       default=None,
                       metavar='N',
                       help=('(EXPERIMENTAL) How many rounds the bound reasoning propagates for (default 4). 0\n'
                             'restricts it to the bounds each literal states on a single variable and the clash\n'
                             'between a lower and an upper bound on one variable. Each further round derives\n'
                             'bounds from inequalities whose other variables are already bounded, which is what\n'
                             'makes an asserted equality act as a substitution.'))

argparser.add_argument('--dpllt-no-bound-var-projection',
                       action='store_true',
                       dest='dpllt_no_bound_var_projection',
                       default=False,
                       help=('(EXPERIMENTAL) Assert the bare conjunction of literals instead of putting the binders\n'
                             'they mention into an existential prefix over it, and read the verdict off the\n'
                             'unprojected intersection. Both decide the formula; the prefix is what makes the\n'
                             'assertion match the shapes the lazy and bounded-congruence constructions require.'))

argparser.add_argument('--dpllt-prefix-cache-entries',
                       type=int,
                       dest='dpllt_prefix_cache_entries',
                       default=None,
                       metavar='N',
                       help=('(EXPERIMENTAL) Bound the cache holding the automata of the prefixes of the asserted\n'
                             'conjunction (default: 4096). 0 disables the cache.'))

argparser.add_argument('--dpllt-show-existential-part',
                       action='store_true',
                       dest='dpllt_show_existential_part',
                       default=False,
                       help=('(EXPERIMENTAL) Print the positive-existential part (chi) that the split found and\n'
                             'exit without evaluating anything. Implies --use-dpllt-automata. The formula printed\n'
                             'is the split\'s own output, before its binders are renamed apart, so its variable ids\n'
                             'are those of the input formula rather than those the per-iteration logs show. A\n'
                             'formula the strategy would decline prints an empty part instead of being evaluated.'))

argparser.add_argument('--dpllt-count-abstraction-models',
                       action='store_true',
                       dest='dpllt_count_abstraction_models',
                       default=False,
                       help=('(EXPERIMENTAL) Print how many models and how many minimal implicants the Boolean\n'
                             'abstraction of the positive-existential part (chi) has, and exit without evaluating\n'
                             'anything. Implies --use-dpllt-automata. The minimal implicant count is the number of\n'
                             'theory calls the loop makes when every assertion it builds is refuted, i.e. its\n'
                             'worst case on this formula. No automaton is constructed, so this reports on formulae\n'
                             'the loop itself could not finish. See --dpllt-abstraction-model-limit.'))

argparser.add_argument('--dpllt-abstraction-model-limit',
                       type=int,
                       dest='dpllt_abstraction_model_enumeration_limit',
                       default=None,
                       metavar='N',
                       help=('(EXPERIMENTAL) Stop either enumeration of --dpllt-count-abstraction-models after N\n'
                             'models and report a lower bound instead (default 1000000). A formula with n\n'
                             'abstracted literals admits up to 2**n models.'))

argparser.add_argument('--dpllt-report',
                       action='store_true',
                       dest='dpllt_report',
                       default=False,
                       help=('(EXPERIMENTAL) Log the DPLL(T) per-run counters (iterations, asserted literals before\n'
                             'and after minimization, cache hits, automaton sizes) after the loop finishes.\n'
                             'Requires --verbose to be visible.'))

# --opt-fixpoint / --opt-budget / --opt-report are NOT -O options and must stay out of
# `opt_to_config_field`: `-O all` iterates that table and would otherwise flip the pipeline on for
# every run, exactly the failure mode --astp-cse and --use-toplevel-sat are also kept out of it to
# avoid. See OPTIMIZATION_PIPELINE_PLAN.md step 5.
argparser.add_argument('--opt-fixpoint',
                       action='store_true',
                       dest='opt_fixpoint',
                       default=None,
                       help=('(EXPERIMENTAL) Run the enabled -O optimizations to a fixpoint via the scheduler in\n'
                             'amaya/preprocessing/pipeline.py, instead of the legacy fixed hand-unrolled sequence.\n'
                             'See OPTIMIZATION_PIPELINE.md.'))

argparser.add_argument('--no-opt-fixpoint',
                       action='store_false',
                       dest='opt_fixpoint',
                       default=None,
                       help='Force the legacy optimization sequence even if the pipeline defaults to enabled.')

argparser.add_argument('--opt-budget',
                       type=int,
                       dest='opt_budget',
                       default=None,
                       metavar='N',
                       help='Cap the fixpoint pipeline (--opt-fixpoint) to N pass applications. Default: derived '
                            'from formula size (32 per 1000 nodes, clamped to [256, 512]).')

argparser.add_argument('--opt-report',
                       action='store_true',
                       dest='opt_report',
                       default=False,
                       help='Log the fixpoint pipeline\'s per-pass statistics table (invocations, productive runs, '
                            'growth discards, time, nodes removed) after preprocessing finishes.')

argparser.add_argument('--opt-trace',
                       action='store_true',
                       dest='opt_trace',
                       default=False,
                       help='Log the formula produced by every productive fixpoint pipeline pass application, in '
                            'order, alongside the name of the pass that produced it. Requires --verbose to be '
                            'visible (uses the same logger as --opt-report).')

argparser.add_argument('-q', '--quiet',
                       action='store_true',
                       default=False,
                       help='Only report most critical messages.')

argparser.add_argument('--domain',
                       choices=['integers', 'naturals'],
                       default='integers',
                       help=('Selects the domain for the automatons constructed'
                             'from atomic presburger formulae. NATURALS support'
                             'is very questionable currently.'))

argparser.add_argument('-m',
                       '--minimize',
                       choices=('hopcroft', 'brzozowski'),
                       dest='minimization_method',
                       default=None,
                       help='Minimize the automatons eagerly using the specified minimization algorithm.')

argparser.add_argument('--use-bit-sets',
                       action='store_true',
                       dest='use_bit_sets',
                       default=False,
                       help='Use bit sets when performing padding closure.')

argparser.add_argument('--shard',
                       dest='sharding_enabled',
                       action='store_true',
                       default=False,
                       help='Perform top-level sharding.')

argparser.add_argument('-p',
                       '--preprocessing',
                       action='append',
                       dest='preprocessing_switches',
                       default=[],
                       choices=['no-var-disambiguation',
                                'assign-new-var-names',
                                'nonlinear-term-use-two-vars',
                                'no-congruences',
                                'assign-new-var-names',
                                'auto-infer',
                       ],
                       help=('Controls preprocessing transformations applied on input the formula. Options:\n'
                             '- no-congruences             : Do not use Congruence atoms when rewriting modulo terms\n'
                             '- assign-new-var-names       : Give all variables a new name, dropping identifies symbols that might be unsupported in some output format\n'
                             '- nonlinear-term-use-two-vars: Always use two variables (quotient, reminder) when rewriting a non-linear term\n'
                             '- auto-infer                 : Convert-mode specific - infer preprocessing options from output format.'))

opt_to_config_field = {
    'gcd-rewrite': 'rewrite_existential_equations_via_gcd',
    'var-bounds': 'simplify_variable_bounds',
    'stomp-negations': 'push_negation_towards_atoms',
    'light-sat': 'do_light_sat_reasoning',
    'lazy': 'do_lazy_evaluation',
    'reorder-conjunctions': 'reorder_conjunctions',
    'minimize-congruences': 'rewrite_congruences_with_unbound_terms',
    'interval-analysis': 'do_interval_analysis',
    'miniscope': 'do_miniscoping',
    'iso-conflicts': 'detect_isomorphic_conflicts',
    'linearize-similar-mod-terms': 'linearize_similar_mod_terms',
    'linearize': 'linearize_congruences',
    'modular-bounds': 'propagate_modular_bounds',
    'purge-twice': 'do_interval_reasonining_twice',
    'opt-bottom-exists': 'optimize_bottom_quantifiers',
    'flatten-connectives': 'flatten_connectives',
    'overapprox-rhs': 'rewrite_by_overapprox_relation_rhs',
    'model-reasoning': 'reason_about_models',
    'infinite-domain': 'remove_vars_used_only_in_disequalities',
    'iniline-bool-definitions': 'inline_bool_var_definitions',  # historical misspelling, kept for benchmark scripts
    'inline-bool-definitions': 'inline_bool_var_definitions',
    'dedup-connective-children': 'deduplicate_connective_children',
    'rce': 'resolve_conditional_equalities',
    'squeeze-elimination': 'eliminate_squeezed_inner_quantifiers',
    'bounded-congruence': 'use_bounded_congruence_construction',
}
optimization_choices = list(opt_to_config_field.keys()) + ['all']

argparser.add_argument('-O',
                       '--optimize',
                       action='append',
                       dest='optimizations',
                       default=[],
                       choices=optimization_choices,
                       help=('Controls preprocessing transformations applied on input the formula. Options:\n'
                             '> gdc-rewrite:\n'
                             '      Rewrite existentially quantified equations using GCD rewrite\n'
                             '> var-bounds:\n'
                             '      Simplify (hard) variable bounds if possible\n'
                             '> stomp-negations:\n'
                             '      Push negation as close to atoms as possible\n'
                             '> lazy:\n'
                             '      Allow lazy evaluation of conjunctions. Requires -m MTBDD.\n'
                             '> light-sat:\n'
                             '      Perform light SAT reasoning on AND-OR trees\n'
                             '> linearize-similar-mod-terms:\n'
                             '      Introduce linear relations between similar mod terms instead of multiple congurences.\n'
                             '         x=(mod x 5) y=(mod (+ 1 x) 5) would lead to y=x+1 (other linearization branches are left out)\n'
                             '> minimize-congruences:\n'
                             '      Minimize congruences terms by replacing multiple terms containin unbound vars with a single term.\n'
                             '> miniscope:\n'
                             '      Perform miniscoping (antiprenexing) on the input formula.\n'
                             '> interval-analysis:\n'
                             '      Use interval analysis to prune formula from conflicting subformulae - e.g. parent asserts that x >= 5 and child asserts that x <= 3.\n'
                             '> iso-conflics:\n'
                             '      Detect conflicts in conjunctive clauses (and A (not B)) if A B are ismorphic modulo bound variable renaming (approximate).\n'
                             '> reorder-conjunctions:\n'
                             '      Reorder conjunctions to derive conflict more quickly.\n'
                             '> flatten-connectives:\n'
                             '      Convert sequences of conjunctions (disjunctions) into one N-ary node.\n'
                             '> overapprox-rhs:\n'
                             '      overapproximate relation RHS and check whether they are always True/False.\n'
                             '> model-reasoning:\n'
                             '      reason about models of the superformula to simplify subformulae.\n'
                             '> dedup-connective-children:\n'
                             '      Remove duplicit children of the AND/OR/EQUIV connectives.\n'
                             '> squeeze-elimination:\n'
                             '      Eliminate an existentially quantified integer variable squeezed between two\n'
                             '         linear bounds whose gap is exactly A - 1, substituting floor(E / A) for it.\n'
                             '> bounded-congruence:\n'
                             '      Build the automaton for an existentially quantified variable bounded from both sides and\n'
                             '         occurring only in a single congruence using a specialized construction. Requires -m MTBDD.\n'
                             '> all:\n'
                             '      Enable all above optimizations'))

argparser.add_argument('-N', '--no-optimize', dest='forbidden_optimizations', choices=optimization_choices, default=[], action='append')


subparsers = argparser.add_subparsers(help='Runner operation')
get_sat_subparser = subparsers.add_parser('get-sat')

get_sat_subparser.add_argument('input_file',
                               metavar='input_file_path',
                               help='The input .smt2 file containing the input formula.')

get_sat_subparser.add_argument('--output-format',
                               metavar='format',
                               choices=['dot', 'vtf', 'mata'],
                               default='dot',
                               dest='output_format',
                               help='Specify the format of the exported automata.')

get_sat_subparser.add_argument('-o'
                               '--output-created-automata',
                               metavar='destination',
                               dest='output_destination',
                               help='Causes the intermediate automata manipulated throughout the decision procedure'
                                    ' to be exported to the given location.')

get_sat_subparser.add_argument('-t',
                               '--print-operations-runtime',
                               action='store_true',
                               dest='should_print_operations_runtime',
                               default=False,
                               help='If present, the runtime of the automata operations performed during the execution'
                                    ' will be measured and printed.')
get_sat_subparser.add_argument('-p',
                               '--print-model',
                               action='store_true',
                               dest='should_print_model',
                               default=False,
                               help='Print model after the decision procedure is finished, if any.')

get_sat_subparser.add_argument('-S',
                               '--show-preprocessed-formula',
                               action='store_true',
                               default=False,
                               help='Pretty print the preprocessed formula into the stdout.')

get_sat_subparser.add_argument('-T',
                               '--show-var-table',
                               action='store_true',
                               default=False,
                               help='Display variable table.')

get_sat_subparser.add_argument('--vis-only-free-vars',
                               action='store_true',
                               dest='vis_display_only_free_vars',
                               default=False,
                               help='Display only tracks only for free variables in the corresponding formula'
                                    ' when exporting automata.')

get_sat_subparser.add_argument('--colorize-dot',
                               action='store_true',
                               dest='colorize_dot',
                               default=False,
                               help='Colorize the SCCs with more than 1 node in the exported automata if the output'
                                    ' format is dot.')

get_sat_subparser.add_argument('-s',
                               '--collect-stats',
                               dest='stats_format',
                               default=None,
                               choices=['csv', 'human'],
                               help='Collect runtime stats and output them in the given format.')

get_sat_subparser.add_argument('-r',
                               '--show-trace-stats',
                               dest='show_trace_stats',
                               default=False,
                               action='store_true',
                               help='Collect statistics abount every single intermediate automaton.')

get_sat_subparser.add_argument('--stats-file',
                               dest='stats_file',
                               help='Collect statistics and output them into the specified file (implies --collect-stats).')

get_sat_subparser.add_argument('--hint-research',
                               action='store_true',
                               default=False,
                               help='Display evaluation phenomena showing optimization potential (e.g. highly effective minimizations).')

get_sat_subparser.add_argument('--max-states',
                               type=int,
                               default=None,
                               metavar='N',
                               help='Stop evaluating the input formula if an intermediate automaton has more than X states.')


benchmark_subparser = subparsers.add_parser('benchmark')
benchmark_subparser.add_argument('--add-file',
                                 metavar='FILE',
                                 action='append',
                                 default=[],
                                 dest='specified_files',
                                 help='Add a file to the performed benchmark')

benchmark_subparser.add_argument('--add-directory-recursive',
                                 default=[],
                                 metavar='DIR',
                                 action='append',
                                 dest='recursive_search_directories',
                                 help='Specify a (recursively searched) directory containing the .smt2 files that are a part of the performed benchmark.')

benchmark_subparser.add_argument('-d'
                                 '--add-directory',
                                 default=[],
                                 metavar='DIR',
                                 action='append',
                                 dest='nonrecursive_search_directories',
                                 help='Specify a directory containing the .smt2 files that are a part of the performed benchmark. Will *not* be recursively traversed.')

benchmark_subparser.add_argument('--execute-times',
                                 type=int,
                                 default=1,
                                 metavar='N',
                                 dest='benchmark_execution_count',
                                 help='Specifies the number of times to execute the whole benchmark.')

benchmark_subparser.add_argument('--output-format',
                                 choices=['json', 'csv'],
                                 metavar='fmt',
                                 dest='output_format',
                                 help='Specifies the output format for the benchmark reports.')

benchmark_subparser.add_argument('--csv-fields',
                                 default='benchmark,avg_runtime,std',
                                 help=('Comma separated fields to print when outputting CSV. Available choices: '
                                       'benchmark (benchmark name), avg_time (average runtime in seconds), '
                                       'std (standard deviation), opt_rounds/opt_termination/opt_pass_sequence/'
                                       'opt_pass_stats (the fixpoint pipeline\'s Pipeline_Report, empty unless '
                                       '--opt-fixpoint was used - see OPTIMIZATION_PIPELINE_PLAN.md step 8)'))

formula_conversion_subparser = subparsers.add_parser('convert')
formula_conversion_subparser.add_argument('file_to_convert', help='File containing SMT2 formula to convert to other format.')
formula_conversion_subparser.add_argument('-f', '--output-format', help='Format to output the formula into.', choices=['lash', 'smt2'], default='smt2')
formula_conversion_subparser.add_argument('--opt', dest='produce_optimization_problem', help='Create an optimization problem out of the given formula.', action='store_true', default=False)

args = argparser.parse_args()

# Determine what mode was used.
if 'specified_files' in args:
    runner_mode = RunnerMode.BENCHMARK
elif 'input_file' in args:
    runner_mode = RunnerMode.GET_SAT
elif 'file_to_convert' in args:
    runner_mode = RunnerMode.CONVERT_FORMULA
    if 'auto-infer' in args.preprocessing_switches:
       if args.output_format == 'lash':
            solver_config.preprocessing.use_congruences_when_rewriting_modulo = False
            solver_config.preprocessing.use_two_vars_when_rewriting_nonlin_terms = True
            solver_config.preprocessing.assign_new_variable_names = True
else:
    print('No execution mode specified. See run-amaya.py --help for more information.', file=sys.stderr)
    sys.exit(1)
logger.debug(f'Chosen runner mode: {runner_mode}')

if args.quiet:
    log_level = logging.CRITICAL
elif args.debug:
    log_level = logging.DEBUG
elif args.verbose:
    log_level = logging.INFO
else:
    log_level = logging.WARNING

logger.setLevel(log_level)
shard_logger.setLevel(log_level)

# Initialize the solver configuration
if args.fast:
    solver_config.backend_type = BackendType.MTBDD
    solver_config.minimization_method = MinimizationAlgorithms.HOPCROFT
else:
    backend_str_to_type = {
        'native': BackendType.NATIVE,
        'MTBDD': BackendType.MTBDD,
    }
    solver_config.backend_type = backend_str_to_type[args.backend]

solution_domain_str_to_type = {
    'naturals': SolutionDomain.NATURALS,
    'integers': SolutionDomain.INTEGERS,
}
solver_config.solution_domain = solution_domain_str_to_type[args.domain]

# Read supplied preprocessing switches and convert them into cfg
if 'no-var-disambiguation' in args.preprocessing_switches:
    solver_config.preprocessing.disambiguate_variables = False
if 'assign-new-var-names' in args.preprocessing_switches:
    solver_config.preprocessing.disambiguate_variables = True
    solver_config.preprocessing.assign_new_variable_names = True
if 'no-congruences' in args.preprocessing_switches:
    solver_config.preprocessing.use_congruences_when_rewriting_modulo = False
if 'nonlinear-term-use-two-vars' in args.preprocessing_switches:
    solver_config.preprocessing.use_two_vars_when_rewriting_nonlin_terms = True

if args.minimization_method == 'hopcroft':
    solver_config.minimization_method = MinimizationAlgorithms.HOPCROFT
elif args.minimization_method == 'brzozowski':
    solver_config.minimization_method = MinimizationAlgorithms.BRZOZOWSKI
    if solver_config.backend_type == BackendType.MTBDD:
        print('Brzozowski minimization is not supported with the MTBDD backend.', file=sys.stderr)
        sys.exit(1)
elif 'fast' not in args:
    solver_config.minimization_method = MinimizationAlgorithms.NONE

if args.use_bit_sets:
    from amaya.mtbdd_transitions import MTBDDTransitionFn
    MTBDDTransitionFn.enable_bit_sets()
    solver_config.backend.use_bit_set_pad_closure = True

solver_config.optimizations.allow_sharding = args.sharding_enabled

if 'all' in args.optimizations:
    for attr in opt_to_config_field.values():
        setattr(solver_config.optimizations, attr, True)
else:
    for opt in args.optimizations:
        setattr(solver_config.optimizations, opt_to_config_field[opt], True)

if 'all' in args.forbidden_optimizations:
    for attr in opt_to_config_field.values():
        setattr(solver_config.optimizations, attr, False)
else:
    for opt in args.forbidden_optimizations:
        setattr(solver_config.optimizations, opt_to_config_field[opt], False)

if args.opt_fixpoint is not None:
    solver_config.optimization_pipeline.enabled = args.opt_fixpoint
if args.opt_budget is not None:
    solver_config.optimization_pipeline.max_pass_applications = args.opt_budget
if args.opt_report:
    solver_config.optimization_pipeline.report = True
if args.opt_trace:
    solver_config.optimization_pipeline.trace = True

# `--astp-cse` is experimental and deliberately kept out of `solver_config`/`opt_to_config_field`
# (see `amaya/cse_cache.py`): enabling it does not flip a `SolverConfig` field, it wraps the
# evaluation call below in `amaya.cse_cache.cse_enabled()`.
use_astp_cse = args.astp_cse

# `--use-toplevel-sat` is experimental and, like `--astp-cse`, not an `-O` optimization: it does not
# tweak preprocessing, it replaces the top-level driver, so it belongs next to the backend/mode
# selection instead of among the flags that compose with the default evaluator. See SAT_TOP_LEVEL.md.
if args.use_toplevel_sat and args.sharding_enabled:
    print('Error: --use-toplevel-sat and --shard are two different strategies for decomposing the same '
          'top-level conjunction and cannot be combined.', file=sys.stderr)
    sys.exit(1)

# `--use-dpllt-automata` is a third top-level driver replacing the same `evaluate_prepared_formula`
# callback, so it excludes both of the above for the same reason they exclude each other. See
# `docs/DPLLT_WITH_AUTOMATA.md`.
if args.use_dpllt_automata and args.sharding_enabled:
    print('Error: --use-dpllt-automata and --shard are two different strategies for decomposing the same '
          'top-level conjunction and cannot be combined.', file=sys.stderr)
    sys.exit(1)

if args.use_dpllt_automata and args.use_toplevel_sat:
    print('Error: --use-dpllt-automata and --use-toplevel-sat are two different top-level drivers and '
          'cannot be combined.', file=sys.stderr)
    sys.exit(1)

# `--dpllt-show-existential-part` and `--dpllt-count-abstraction-models` are debug views of the split
# and of its abstraction, which only this strategy performs, so they select the strategy rather than
# being silently ignored without --use-dpllt-automata.
solver_config.dpllt_automata.enabled = (args.use_dpllt_automata or args.dpllt_show_existential_part
                                        or args.dpllt_count_abstraction_models)
solver_config.dpllt_automata.use_bounds_refutation = not args.dpllt_no_bounds_refutation
if args.dpllt_bound_propagation_rounds is not None:
    solver_config.dpllt_automata.bound_propagation_rounds = args.dpllt_bound_propagation_rounds
solver_config.dpllt_automata.show_positive_existential_part = args.dpllt_show_existential_part
solver_config.dpllt_automata.count_abstraction_models = args.dpllt_count_abstraction_models
if args.dpllt_abstraction_model_enumeration_limit is not None:
    solver_config.dpllt_automata.abstraction_model_enumeration_limit = args.dpllt_abstraction_model_enumeration_limit
if args.dpllt_assertion_optimizer is not None:
    solver_config.dpllt_automata.assertion_optimizer = args.dpllt_assertion_optimizer
if args.dpllt_no_implicant_minimization:
    solver_config.dpllt_automata.minimize_implicants = False
if args.dpllt_no_bound_var_projection:
    solver_config.dpllt_automata.project_bound_vars = False
if args.dpllt_prefix_cache_entries is not None:
    solver_config.dpllt_automata.prefix_cache_max_entries = args.dpllt_prefix_cache_entries
if args.dpllt_report:
    solver_config.dpllt_automata.report = True


def get_evaluation_strategy():
    """
    The `evaluate_prepared_formula` callback handed to `parse.perform_whole_evaluation_on_source_text`.

    `amaya.sat_toplevel` and `amaya.dpllt_automata` are imported lazily (like `amaya.cse_cache` below)
    so that the python-sat dependency is only ever touched when the feature is explicitly requested.
    """
    if solver_config.dpllt_automata.enabled:
        from amaya.dpllt_automata import evaluate_prepared_formula_with_dpllt_automata
        return evaluate_prepared_formula_with_dpllt_automata

    if not args.use_toplevel_sat:
        return parse.evaluate_prepared_formula_with_automata

    from amaya.sat_toplevel import evaluate_prepared_formula_with_toplevel_sat
    return functools.partial(evaluate_prepared_formula_with_toplevel_sat,
                             use_generalized_blocking=not args.toplevel_sat_exact_blocking)

def ensure_output_destination_valid(output_destination: str):
    """Ensures that the given output destination is a folder. Creates the folder if it does not exist."""
    if os.path.exists(output_destination):
        if not os.path.isdir(output_destination):
            print('Error: The automaton output destination must be a folder, not a file.', file=sys.stderr)
            sys.exit(1)
    else:
        os.mkdir(output_destination)


def search_directory_recursive(root_path: str, filter_file_ext='.smt2') -> List[str]:
    matching_paths: List[str] = []
    for dir_name, directories, files in os.walk(root_path):
        for file in files:
            if file.endswith(filter_file_ext):
                matching_paths.append(os.path.join(dir_name, file))
    return matching_paths


def search_directory_nonrecursive(root_path: str, filter_file_ext='.smt2') -> List[str]:
    return list(
        map(
            lambda benchmark_file: os.path.join(root_path, benchmark_file),
            filter(
                lambda path: path.endswith(filter_file_ext),
                os.listdir(root_path)
            )
        )
    )


Row_Type = Tuple[int, str, Optional[int], Optional[int], Optional[int], Optional[int], int, int]


def display_runtime_statistics(output_file: Optional[str], format: Optional[str], result: parse.Evaluation_Result, show_trace_stats: bool = False):
    output_file_handle = sys.stdout if not output_file else open(output_file, 'w')
    format = 'human' if not format else format

    if result.solutions_nfa is not None:
        solution_space_nfa_state_cnt_info = str(len(result.solutions_nfa.states))
    elif result.shards:
        solution_space_nfa_state_cnt_info = ' * '.join(str(len(nfa.states)) for nfa in result.shards)
    else:
        solution_space_nfa_state_cnt_info = '?'

    def row_from_stat_point(op_idx: int, point: StatPoint) -> Row_Type:
        id = op_idx
        op_type = point.operation.value
        output_size = point.output.size
        runtime = point.runtime_ns

        op1_id, op1_size = None, None
        if point.operand1:
            op1_id, op1_size = point.operand1.automaton_id, point.operand1.size

        op2_id, op2_size = None, None
        if point.operand2:
            op1_id, op1_size = point.operand2.automaton_id, point.operand2.size

        return (id, op_type, op1_id, op1_size, op2_id, op2_size, output_size, runtime)

    if format == 'human':
        import tabulate, functools
        write_stat = functools.partial(print, file=output_file_handle)
        write_stat(f'############ STATISTICS ############')
        write_stat(f'result_size       : {solution_space_nfa_state_cnt_info}')
        write_stat(f'max_automaton_size: {result.run_stats.max_automaton_size}')
        if show_trace_stats:
            write_stat(f'### Trace: ')
            header = ['id', 'operation', 'Operand1 id', 'Operand1 Size', 'Operand2 id', 'Operand2 Size', 'Output Size', 'runtime (ns)']
            rows = [row_from_stat_point(i, row) for i, row in enumerate(result.run_stats.trace)]
            write_stat(tabulate.tabulate(rows, headers=header))
    elif format == 'csv':
        import csv
        header = ['id', 'operation', 'operand1_id', 'operand1_size', 'operand2_id', 'operand2_size', 'output_size', 'runtime_ns']
        rows = [row_from_stat_point(i, row) for i, row in enumerate(result.run_stats.trace)]
        writer = csv.writer(output_file_handle)
        writer.writerow(header)
        writer.writerows(rows)

    if output_file is not None:
        output_file_handle.close()


def run_in_getsat_mode(args) -> bool:
    assert os.path.exists(args.input_file), 'The SMT2 supplied file containing input formula does not exists!'
    assert os.path.isfile(args.input_file), 'The supplied file must not be a directory.'

    # Statistics
    solver_config.print_stats = args.stats_format is not None or args.stats_file is not None
    solver_config.track_operation_runtime = args.should_print_operations_runtime or solver_config.print_stats

    solver_config.vis_display_only_free_vars = args.vis_display_only_free_vars
    solver_config.current_formula_path = os.path.abspath(args.input_file)
    solver_config.preprocessing.show_preprocessed_formula = args.show_preprocessed_formula
    solver_config.preprocessing.display_var_table = args.show_var_table
    solver_config.max_allowed_states = args.max_states

    solver_config.report_highly_effective_minimizations = args.hint_research

    def write_created_automaton_to_folder(introspection_info: core.IntrospectionData):
        filename = f'{introspection_info.operation_id}-{introspection_info.operation.value}.{args.output_format}'
        output_path = os.path.join(args.output_destination, filename)
        with open(output_path, 'w') as output_file:
            vis_representation = introspection_info.result.get_visualization_representation().compress_symbols()
            output_contents = ''
            if args.output_format == 'dot':
                output_contents = str(vis_representation.into_graphviz(highlight_sccs=args.colorize_dot))
            elif args.output_format == 'vtf':
                output_contents = vis_representation.into_vtf()
            elif args.output_format == 'mata':
                output_contents = vis_representation.into_mata()
            output_file.write(output_contents)

    def discard_created_automaton(_: core.IntrospectionData):
        pass

    should_output_created_automata = bool(args.output_destination)

    if should_output_created_automata:
        ensure_output_destination_valid(args.output_destination)
        handle_automaton_created_fn = write_created_automaton_to_folder
    else:
        handle_automaton_created_fn = discard_created_automaton

    was_result_correct = True  # If the SMT file provides :status
    with open(args.input_file) as input_file:
        input_text = input_file.read()
        logger.info(f'Executing evaluation procedure with configuration: {solver_config}')

        try:
            result = parse.perform_whole_evaluation_on_source_text(
                input_text, handle_automaton_created_fn,
                evaluate_prepared_formula=get_evaluation_strategy())
        except NonlinearArithmeticError as err:
            logger.debug('Input formula is not a valid LIA formula. Reason: %s', err)
            print('unknown')
            sys.exit(0)

        if not result:
            return True  # There was no check-sat directive, just exit

        computed_sat = 'sat' if result.model is not None else 'unsat'
        logger.info(f'The SAT value of the result automaton is {computed_sat}')

        print(computed_sat)
        if args.should_print_model and result.model is not None:
            print('model:')
            model = cast(Dict[Var, int], result.model)
            displayed_model_lines: List[Tuple[str, str]] = []

            for var, var_value in model.items():
                var_info = result.var_table[var]
                if var_info.type == VariableType.BOOL:
                    var_value = 'true' if var_value else 'false'
                displayed_model_lines.append((var_info.name, str(var_value)))

            for var_name, var_value in sorted(displayed_model_lines, key=lambda pair: pair[0]):
                print(f' {var_name} = {var_value}')

        # display_runtime_statistics(args.stats_file, args.stats_format, nfa, stats, show_trace_stats=args.show_trace_stats)

        if should_output_created_automata:
            # Dump tracefile
            trace_file = 'trace-info.dot'
            trace_path = os.path.join(args.output_destination, trace_file)
            with open(trace_path, 'w') as trace_out_file:
                trace_graph = utils.construct_dot_tree_from_trace(result.run_stats.trace)
                trace_out_file.write(trace_graph)

        return was_result_correct


def print_benchmark_results_as_csv(results: Dict[str, BenchmarkStat], args, separator=';'):
    """Prints the benchmark results as a CSV with fields given by the args.csv_fields."""

    requested_csv_fields = args.csv_fields.split(',')
    # opt_* fields surface the `Pipeline_Report` collected under `--opt-report`/`--opt-fixpoint`
    # (plan step 8); they are empty for a benchmark run without the pipeline enabled.
    supported_csv_fields = {'benchmark', 'avg_runtime', 'std', 'opt_rounds', 'opt_termination',
                            'opt_pass_sequence', 'opt_pass_stats'}

    csv_fields = []
    for field in requested_csv_fields:
        if field in supported_csv_fields:
            csv_fields.append(field)
        else:
            print(f'Unknown CSV field {field}, skipping it.', file=sys.stderr)

    def make_column_map(benchmark: str, result: BenchmarkStat, columns: List[str]) -> Dict[str, str]:
        column_map = {
            'avg_runtime': str(cast(float, result.avg_runtime_ns) / 1_000_000_000),
            'benchmark': benchmark,
        }
        if 'std' in columns:
            column_map['std'] = str(round(statistics.stdev(result.runtimes_ns) / 1_000_000_000))

        report = result.pipeline_report
        if 'opt_rounds' in columns:
            column_map['opt_rounds'] = str(report.rounds) if report else ''
        if 'opt_termination' in columns:
            column_map['opt_termination'] = report.termination if report else ''
        if 'opt_pass_sequence' in columns:
            column_map['opt_pass_sequence'] = ' '.join(report.pass_sequence) if report else ''
        if 'opt_pass_stats' in columns:
            if report is None:
                column_map['opt_pass_stats'] = ''
            else:
                column_map['opt_pass_stats'] = json.dumps({
                    name: {'invocations': stat.invocations, 'productive': stat.productive,
                          'discarded_for_growth': stat.discarded_for_growth,
                          'total_time_ns': stat.total_time_ns, 'nodes_removed': stat.nodes_removed}
                    for name, stat in report.pass_stats.items()
                })
        return column_map

    rows = []
    for benchmark, result in results.items():
        column_map = make_column_map(benchmark, result, csv_fields)
        row_parts = [column_map[field] for field in csv_fields]
        rows.append(separator.join(row_parts))
    print('\n'.join(rows))


def run_in_benchmark_mode(args) -> bool:  # NOQA
    benchmark_files: List[str] = []
    for benchmark_file in args.specified_files:
        assert os.path.exists(benchmark_file) and os.path.isfile(benchmark_file), f'The file in --add-file {benchmark_file} does not exists.'
        benchmark_files.append(benchmark_file)

    for nonrecursive_search_directory in args.nonrecursive_search_directories:
        benchmark_files += search_directory_nonrecursive(nonrecursive_search_directory)

    for recursive_search_directory in args.recursive_search_directories:
        benchmark_files += search_directory_recursive(recursive_search_directory)

    print('Executing benchmark with the following files:', file=sys.stderr)
    for f in benchmark_files:
        print(' > ', f, file=sys.stderr)

    executed_benchmarks: Dict[str, BenchmarkStat] = {}
    failed = 0

    if solver_config.backend_type == parse.BackendType.MTBDD:
        from amaya.mtbdd_transitions import MTBDDTransitionFn

    for i in range(args.benchmark_execution_count):
        for benchmark_file in benchmark_files:
            if benchmark_file in executed_benchmarks and executed_benchmarks[benchmark_file].failed:
                # Skip benchmarks that have previously failed
                continue

            with open(benchmark_file) as benchmark_input_file:
                # Clear sylvan cache if running multiple evaluations, so that the measurements do not interfere.
                if solver_config.backend_type == parse.BackendType.MTBDD:
                    from amaya.mtbdd_transitions import MTBDDTransitionFn
                    # MTBDDTransitionFn.call_clear_cachce()
                    # MTBDDTransitionFn.call_sylvan_gc()

                print('Running', benchmark_file, file=sys.stderr)
                solver_config.export_counter = 0
                solver_config.current_formula_path = os.path.abspath(benchmark_file)
                text = benchmark_input_file.read()

                benchmark_start = time.time_ns()
                result = parse.perform_whole_evaluation_on_source_text(
                    text, evaluate_prepared_formula=get_evaluation_strategy())
                benchmark_end = time.time_ns()
                runtime_ns = benchmark_end - benchmark_start

                if benchmark_file not in executed_benchmarks:
                    executed_benchmarks[benchmark_file] = BenchmarkStat(os.path.basename(benchmark_file),
                                                                        benchmark_file,
                                                                        [runtime_ns],
                                                                        False)
                else:
                    executed_benchmarks[benchmark_file].runtimes_ns.append(runtime_ns)

                if not result:
                    continue

                if result.pipeline_report is not None:
                    executed_benchmarks[benchmark_file].pipeline_report = result.pipeline_report

                expected_sat_str = result.smt_info.get(':status', 'unknown')
                if expected_sat_str in ('sat', 'unsat'):
                    sat = result.model is not None
                    expected_sat = (expected_sat_str == 'sat')
                    if sat != expected_sat:
                        failed += 1
                        executed_benchmarks[benchmark_file].failed = True

    print(f'Failed: {failed}/{len(benchmark_files)}', file=sys.stderr)
    if failed:
        failed_tests = [run_sample.path for run_sample in executed_benchmarks.values()]
        print(f'Failed tests:', file=sys.stderr)
        for run_sample in executed_benchmarks.values():
            if run_sample.failed:
                print(f'  - {run_sample.path}')

    report = list(map(BenchmarkStat.as_dict, executed_benchmarks.values()))

    if args.output_format == 'json':
        print(json.dumps(report))
    elif args.output_format == 'csv':
        print_benchmark_results_as_csv(executed_benchmarks, args)

    return not failed


Writer_Type = Callable[[ASTp_Node, Iterable[Tuple[Var, VarInfo]], Dict[Var, VarInfo], Dict[str, str]], str]


def convert_smt_to_other_format(args):
    if not os.path.exists(args.file_to_convert):
        sys.exit(f'The specified input file {args.file_to_convert} does not exists!')

    with open(args.file_to_convert) as input_file:
        smt2_text = input_file.read()

    tokens = tokenize(smt2_text)
    ast: List[AST_Node] = parse.build_syntax_tree(tokens)

    writer_table: Dict[str, Writer_Type] = {
        'lash': write_ast_in_lash,
        'smt2': write_ast_in_smt2,
    }

    function_symbol_table: Dict[str, FunctionSymbol] = {}
    asserted_formulae: List[AST_Node] = []
    writer = writer_table[args.output_format]

    smt_info: Dict[str, str] = {}

    for top_level_statement in ast:
        if not isinstance(top_level_statement, list):
            continue
        if top_level_statement[0] == AST_Node_Names.DECLARE_FUN.value:
            function_symbol = parse.parse_function_symbol_declaration(top_level_statement)
            function_symbol_table[function_symbol.name] = function_symbol
        elif top_level_statement[0] == AST_Node_Names.ASSERT.value:
            asserted_formulae.append(top_level_statement[1])
        elif top_level_statement[0] == AST_Node_Names.CHECK_SAT.value:
            fn_symbols = [fn_symbol for fn_symbol in function_symbol_table.values() if fn_symbol.arity == 0]
            fn_symbols = sorted(fn_symbols, key=lambda fn_symbol: fn_symbol.name)
            formula_to_emit = ['and', *asserted_formulae]
            formula_to_emit, var_table = preprocess_ast(formula_to_emit, global_fn_symbols=fn_symbols)
            astp = parse.optimize_formula_structure(formula_to_emit, var_table)

            if args.produce_optimization_problem:
                params = [var for var, var_info in var_table.items() if var_info.is_formula_param]
                astp = generate_optimization_problem(astp, var_table, params)

            formula_parameters = [(var, var_info) for var, var_info in var_table.items() if var_info.is_formula_param]
            output = writer(astp, formula_parameters, var_table, smt_info)

            print(output)

            # We are not catching any errors here, if an exception is raised it will kill the interpreter and the exit code
            # will be non-zero
            return True
        elif top_level_statement[0] == AST_Node_Names.SET_INFO.value:
            field = cast(str, top_level_statement[1])
            field = field[1:]  # strip the leading ':' from :category 
            field_value = cast(str, top_level_statement[2])
            smt_info[field] = field_value

running_modes_procedure_table = {
    RunnerMode.BENCHMARK: run_in_benchmark_mode,
    RunnerMode.GET_SAT: run_in_getsat_mode,
    RunnerMode.CONVERT_FORMULA: convert_smt_to_other_format,
}

cse_context: contextlib.AbstractContextManager = contextlib.nullcontext()
if use_astp_cse:
    # Imported lazily so that the module (and the `MTBDD_NFA.renamed_copy` it installs) is only
    # ever touched when explicitly requested via `--astp-cse`.
    from amaya.cse_cache import cse_enabled
    cse_context = cse_enabled()

with cse_context:
    run_successful = running_modes_procedure_table[runner_mode](args)
sys.exit(0 if run_successful else 1)
