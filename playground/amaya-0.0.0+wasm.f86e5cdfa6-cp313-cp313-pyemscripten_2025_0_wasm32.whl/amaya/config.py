from dataclasses import (
    dataclass,
    field,
)
from enum import IntEnum
from typing import Dict, Optional


class SolutionDomain(IntEnum):
    NATURALS = 0
    INTEGERS = 1


class BackendType(IntEnum):
    NATIVE = 1
    MTBDD = 2


class MinimizationAlgorithms(IntEnum):
    NONE = 0
    HOPCROFT = 1
    BRZOZOWSKI = 2


@dataclass
class BackendConfig(object):
    use_bit_set_pad_closure: bool = True
    """
    Represent the pad-closure frontier as a bit set indexed by state number instead of a sorted
    vector of states. Both implementations compute the same frontier with the same number of MTBDD
    applications; the bit set makes every leaf update a fixed-width word copy instead of copying and
    re-sorting a vector that grows with the frontier, which is where the old representation spent
    its time. Only worth turning off for automata so large that a full |Q|-bit frontier leaf costs
    more to copy than the handful of states the frontier actually holds.
    """


@dataclass
class OptimizationsConfig:
    allow_sharding: bool = False
    """ Perform top-level sharding. """

    simplify_variable_bounds: bool = False
    """Simplify hard variable bounds, e.g, x >= 0 && x != 0 ---> x >= 1."""

    rewrite_existential_equations_via_gcd: bool = False
    """Rewrite (exists x (= k*x y)) into (y mod k) = 0."""

    push_negation_towards_atoms: bool = False
    """Push negations as close to atoms as possible."""

    remove_vars_used_only_in_disequalities: bool = False
    """
    Drop existentially quantified variables (of an infinite sort) that occur only in disequalities.

    Example:
        (exists ((x Int)) (and (<= y 0) (not (= x 5))))   --->   (<= y 0)
    """

    do_interval_analysis: bool = True
    """
    Use interval analysis to prune the formula from simple conflicting clauses.

    Examle:
        parent asserts x >= 4 and a child asserts that x <= 2
    """

    do_light_sat_reasoning: bool = False
    """Detect AND-OR trees and convert them into DNF form and detect contradictions."""

    do_lazy_evaluation: bool = False
    """Enable lazy evaluation of subformulae of the form `(exists (..) (and atom1 atom2 ...))`"""

    do_miniscoping: bool = False
    """ Perform miniscoping (antiprenexing) on the formula. """

    do_gcd_divide: bool = True
    """ Divide atoms by the GCD of their coefficients. """

    rewrite_by_overapprox_relation_rhs: bool = False
    """ Compute overapproximation of relation's RHS and check whether the relation is always True/False. """

    rewrite_congruences_with_unbound_terms: bool = False
    """ Rewrite congruences a.x + b.y ~ k into a.x + gcd(b).y' ~ k """

    detect_isomorphic_conflicts: bool = False
    """
    Detect conflicts in (and A (not A)) if A and not A are the same modulo bound variable renaming.

    Isomorphism is underapproximated at the moment using the first naive permutation of quantified variables.
    """

    linearize_similar_mod_terms: bool = False
    """Introduce a linear relations between two variables for similar mod terms instead of using congruences."""

    reorder_conjunctions: bool = False
    """Reorder conjunctions to derive conflict more quickly."""

    do_interval_reasonining_twice: bool = False
    """If True, and do_interval_analysis is True, then an additional pass of tree pruning will be done at the end of preprocessing."""

    linearize_congruences: bool = False
    """Convert congruences to linear functions where possible."""

    optimize_bottom_quantifiers: bool = False
    """
    Optimize bottom existential quantifiers.

    Optimizations:
        - remove (exists x PHI) if PHI can be satisfied wlog by setting x to +Inf or -Inf
        - remove (exists x PHI) if a fixed "best" value can be determined for x
    """

    flatten_connectives: bool = False
    """ Convert sequances of (binary) ANDs/ORs into one N-ary node. """

    reason_about_models: bool = False
    """ Reason about models of a superformula to simplify subformulae. """

    inline_bool_var_definitions: bool = False
    """
    Inline unconditionally-true "definitions" of Bool variables, e.g. conjuncts of the form `(= bool_var phi)`,
    by substituting every occurrence of bool_var with phi and dropping the now-tautological equivalence.

    Example:
        (and (= b (or x y)) (or b z))   --->   (or x y z)
    """

    deduplicate_connective_children: bool = False
    """
    Remove duplicit children of the AND/OR/EQUIV connectives. The subformulae are identified using
    IDs assigned to them based on their structure, so the duplicities are detected modulo the ordering
    of the children of a connective and the ordering of the terms of an atom.

    Example:
        (and (<= x 0) (or A B) (<= x 0))   --->   (and (<= x 0) (or A B))
    """

    resolve_conditional_equalities: bool = False
    """
    Eliminate existentially quantified variables occurring only in "conditional equalities" hidden
    inside disjunctions.

    Example:
        (exists ((x Int)) (and (or A (= x t1)) (or B (= x t2))))   --->   (or A B (= t1 t2))
    """

    eliminate_squeezed_inner_quantifiers: bool = False
    """
    Eliminate an existentially quantified integer variable squeezed between two linear bounds
    whose gap is exactly `A - 1`, which forces the variable to a unique value `floor(E / A)`. See
    docs/QSE.md and docs/QSE_IMPLEMENTATION_PLAN.md.

    Example:
        (exists ((y Int)) (and (<= (* 10 y) (* 9 x)) (<= (* 9 x) (+ (* 10 y) 9))))   --->   True
    """

    propagate_modular_bounds: bool = False
    """
    (EXPERIMENTAL) Eliminate quantified variables that a congruence determines, carrying their bounds
    forward as modular interval constraints.

    Targets an existential block whose body conjoins hard bounds with congruences of one modulus - the
    shape a machine-arithmetic encoding produces, where the modulus is `2**32`. A congruence of modulus
    `m` costs an automaton on the order of `m`, so removing one is worth far more than the nodes it
    costs. Facts that share variables are combined without approximation into unions of intervals.
    Applied only when the rewritten block has strictly fewer congruences; a block containing a fact
    that holds for no assignment is replaced by False. See `amaya/preprocessing/modular_bounds.py`.
    """

    use_bounded_congruence_construction: bool = False
    """
    Build the automaton for an existentially quantified variable that is bounded from both sides and
    occurs (besides the bounds themselves) only in a single congruence using a specialized construction
    instead of projecting the variable away afterwards. Requires -m MTBDD.

    Example:
        (exists ((x Int)) (and (<= 0 x) (<= x 3) (= (mod (+ (* 3 x) y) 8) 1)))

    All instantiations of the bounded variable share a single congruence state graph, so the resulting
    automaton is built in one sweep and holds at most `2*modulus` states regardless of how wide the
    bounds are. See BOUNDED_CONGRUENCE.md.
    """


@dataclass
class OptimizationPipelineConfig:
    """See OPTIMIZATION_PIPELINE.md / OPTIMIZATION_PIPELINE_PLAN.md."""

    enabled: bool = False
    """
    Run the registered optimizations to a fixpoint via `amaya.preprocessing.pipeline`, instead of
    the legacy hand-unrolled straight-line sequence.

    Defaults to False until the differential validation gate (plan step 7) is clean and step 9
    has re-tuned the tiers from real benchmark data - so that a bad merge here cannot affect a
    benchmark run or an SMT-COMP submission that does not explicitly ask for it.
    """

    max_pass_applications: Optional[int] = None
    """None = derive from formula size (32 per 1000 nodes, clamped to [256, 512] - see
    `pipeline._default_max_pass_applications`'s docstring for why the floor is 256, not 32)."""

    max_wall_time_seconds: float = 0.0
    """0 = no time limit."""

    tier_overrides: Dict[str, int] = field(default_factory=dict)
    """Pass name -> Pass_Tier value; for experimentation without editing the registry."""

    max_runs_overrides: Dict[str, int] = field(default_factory=dict)
    """Pass name -> max_runs; for experimentation without editing the registry."""

    report: bool = False
    """Log the per-pass statistics table after the pipeline finishes."""

    trace: bool = False
    """
    Log the formula produced by every productive pass application, in order, alongside the name of
    the pass that produced it - a step-by-step record of how the formula was simplified, for
    debugging a specific pipeline run. Also collected into `Pipeline_Report.trace` for programmatic
    inspection.
    """


ASSERTION_OPTIMIZER_MODE_NONE = 'none'
ASSERTION_OPTIMIZER_MODE_RESTRICTED = 'restricted'
ASSERTION_OPTIMIZER_MODE_FULL = 'full'

ASSERTION_OPTIMIZER_MODES = (ASSERTION_OPTIMIZER_MODE_NONE,
                             ASSERTION_OPTIMIZER_MODE_RESTRICTED,
                             ASSERTION_OPTIMIZER_MODE_FULL)


@dataclass
class DpllTAutomataConfig:
    """
    (EXPERIMENTAL) Configuration of the DPLL(T)-style top-level strategy implemented in
    `amaya/dpllt_automata.py`. See `docs/DPLLT_WITH_AUTOMATA.md`.
    """

    enabled: bool = False
    """ Select `amaya.dpllt_automata.evaluate_prepared_formula_with_dpllt_automata` as the top-level driver. """

    assertion_optimizer: str = ASSERTION_OPTIMIZER_MODE_RESTRICTED
    """
    Which passes the per-iteration assertion is optimized with; one of `ASSERTION_OPTIMIZER_MODES`.

    `none` hands the assertion to the evaluator unoptimized. `restricted` runs the fixpoint pipeline
    with the registry filtered to the passes classified as solution-set-preserving over free
    variables (`amaya.dpllt_automata.ASSERTION_OPTIMIZER_SOLUTION_SET_PRESERVING_PASSES`, currently
    empty, so `restricted` behaves as `none`). `full` runs the whole enabled registry and is known to
    be unsound - see `docs/DPLLT_WITH_AUTOMATA.md` §7.2 - it exists to measure what the pipeline
    would buy if the classification turned out favourable.
    """

    minimize_implicants: bool = True
    """ Reduce the literal set the SAT solver reports to a minimal implicant of the abstraction. """

    use_bounds_refutation: bool = True
    """
    Before the theory call, reason over the variable bounds of the asserted literals and, on a
    contradiction, refute the assertion without constructing an automaton.

    The literals the contradiction was derived from are an unsatisfiable subset of the assertion on
    their own, so the blocking clause is built over those instead of the whole implicant, which
    removes every literal set containing them rather than only the supersets of this implicant. See
    `amaya.dpllt_automata.find_bounds_refutation` for the rules applied.
    """

    bound_propagation_rounds: int = 4
    """
    How many rounds the bound reasoning of `use_bounds_refutation` propagates for.

    0 restricts it to what needs no propagation: the bounds each literal states on a single variable,
    the clash between a lower and an upper bound on one variable, and the check that no asserted
    inequality has a least value exceeding its right-hand side. Each further round derives bounds from
    inequalities whose other variables are already bounded, which is what makes an asserted equality
    act as a substitution; a chain of `n` equalities needs `n` rounds to carry a bound from one end to
    the other. See `amaya.dpllt_automata.MAX_BOUND_PROPAGATION_ROUNDS`.
    """

    project_bound_vars: bool = True
    """
    Retain the hoisted existential prefix on the assertion, so the bound variables are projected away
    before the intersection with the automaton for the general part. With this off, the assertion is
    the bare conjunction and the verdict is read off the unprojected intersection.
    """

    prefix_cache_max_entries: int = 4096
    """ Bound on the conjunction-prefix automaton cache; 0 disables the cache. """

    max_optimizer_invocations: Optional[int] = None
    """ Cap on the total number of assertion-optimizer runs per solved formula; None = no cap. """

    report: bool = False
    """ Log the per-run counters after the loop finishes. """

    show_positive_existential_part: bool = False
    """
    Print the positive-existential part the split found and exit without evaluating anything.

    The formula printed is the split's own output, before its binders are renamed apart, so its
    variable ids are those of the input formula. The display happens before either fall-through, so an
    input the strategy would decline reports an empty part rather than being evaluated.
    """

    count_abstraction_models: bool = False
    """
    Print how many models and how many minimal implicants the Boolean abstraction of the
    positive-existential part has, and exit without evaluating anything.

    The minimal implicant count is the number of theory calls the loop makes when every assertion is
    refuted. Constructs no automaton, so it reports on formulae the loop itself could not finish.
    """

    abstraction_model_enumeration_limit: int = 1000000
    """
    Cap on either enumeration performed by `count_abstraction_models`; a count that reaches it is
    reported as a lower bound. A formula with `n` abstracted literals admits up to `2**n` models.
    """


@dataclass
class PreprocessingConfig:
    perform_antiprenexing: bool = False
    disambiguate_variables: bool = True
    assign_new_variable_names: bool = False
    """ Completely drop the variable names found in the AST and assign new ones. Implies disambiguation."""

    use_congruences_when_rewriting_modulo: bool = True
    """Use the congruence atom types to rewrite modulo terms."""

    use_two_vars_when_rewriting_nonlin_terms: bool = False
    """Use two variables <d> and <m> as in `K*<d> + <m> = y` when rewriting nonlinear terms."""

    show_preprocessed_formula: bool = False
    """Show preprocessed formula and exit; do not evaluate."""

    display_var_table: bool = False
    """Print variable table and exit."""


@dataclass
class SolverConfig(object):
    """Solver configuration options."""
    solution_domain: SolutionDomain = SolutionDomain.INTEGERS
    minimization_method: MinimizationAlgorithms = MinimizationAlgorithms.NONE
    # Performance tracking options
    backend_type: BackendType = BackendType.NATIVE
    track_operation_runtime: bool = False
    track_state_semantics: bool = False

    optimizations: OptimizationsConfig = field(default_factory=OptimizationsConfig)

    optimization_pipeline: OptimizationPipelineConfig = field(default_factory=OptimizationPipelineConfig)
    """Fixpoint scheduler configuration - see `OptimizationPipelineConfig`."""

    dpllt_automata: DpllTAutomataConfig = field(default_factory=DpllTAutomataConfig)
    """(Experimental) DPLL(T)-style top-level strategy configuration - see `DpllTAutomataConfig`."""

    backend: BackendConfig = field(default_factory=BackendConfig)

    vis_display_only_free_vars: bool = False
    """Export transition symbols with bits only for the free variables in the corresponding automaton."""

    print_stats: bool = False
    """Print execution statistics"""

    preprocessing: PreprocessingConfig = field(default_factory=PreprocessingConfig)
    """Preprocessing configuration options."""

    current_formula_path: Optional[str] = None
    """Path to the input formula, if provided."""

    export_counter: int = 0
    """(Experimental) An execution-local repurposable counter."""

    disambiguation_scope_separator: str = '_'
    """String to use when disambiguating quantified variables, producing new var names of the form {old_name}{separator}{scope_id}."""

    report_highly_effective_minimizations: bool = False
    """Log subformula for which was the minimization highly effective (the resuld is smaller than 0.2* original size)."""

    max_allowed_states: int | None = None
    """Terminate the evaluation if any intermediate automaton gets larger than the given limit."""


solver_config = SolverConfig()
