from __future__ import annotations
from dataclasses import (
    dataclass,
    field,
)
from enum import Enum, IntEnum
import functools
import math
from typing import (
    Any,
    Callable,
    Generator,
    Iterable,
    List,
    Dict,
    Generic,
    Optional,
    Tuple,
    TypeVar,
    Set,
    Union,
)


@dataclass(frozen=True)
class Var:
    id: int

    def __lt__(self, other: Var) -> bool:
        return self.id < other.id

    def __gt__(self, other: Var) -> bool:
        return self.id > other.id


@dataclass
class Relation(object):
    """
    Represents one atomic PrA constraint.

    Might contain modulo terms or div terms that are not evaluable directly and must be expressed in terms
    of existential quantifier.
    """
    vars: List[Var]
    coefs: List[int]
    rhs: int
    predicate_symbol: str

    id: int = -1
    _id: int = field(default=-1, compare=False, repr=False)

    def are_all_coefficients_zero(self) -> bool:
        """Returns true if all relation variable coefficients are zero."""
        return all(coef == 0 for coef in self.coefs)

    def linear_terms(self) -> Generator[Tuple[int, Var], None, None]:
        for coef, var in zip(self.coefs, self.vars):
            yield (coef, var)

    def is_always_satisfied(self) -> bool:
        """
        Returns true if all the variable cooeficients are zero and the relation is satisfied."""

        are_all_coefs_zero = self.are_all_coefficients_zero()

        if are_all_coefs_zero:
            absolute_part_conditions: Dict[str, Callable[[int], bool]] = {
                '<': lambda absolute_part: absolute_part > 0,
                '<=': lambda absolute_part: absolute_part >= 0,
                '=': lambda absolute_part: absolute_part == 0,
            }

            absolute_part_condition = absolute_part_conditions[self.predicate_symbol]
            return absolute_part_condition(self.rhs)
        return False

    def _format_term_type_into_string(self,
                                      coefs: Iterable[int],
                                      vars: List[Var],
                                      use_latex_notation: bool = False) -> Generator[str, None, None]:
        if use_latex_notation:
            var_coef_iterator = iter(zip(coefs, vars))
            first_var_coef_name_pair = next(var_coef_iterator, None)
            if not first_var_coef_name_pair:
                return
            first_var_coef, first_var_name = first_var_coef_name_pair
            yield '{0}{1}'.format(first_var_coef if first_var_coef != 1 else '', first_var_name)
            for coef, var_name in var_coef_iterator:
                yield '{sign} {coef_abs}{var_name}'.format(
                    sign='+' if coef >= 0 else '-', coef_abs=abs(coef) if abs(coef) != 1 else '', var_name=var_name
                )
        else:
            for coef, var_name in zip(coefs, vars):
                yield '{0}{1}.{2}'.format(('+' if coef >= 0 else ''), coef, var_name)

    def into_string(self, use_latex_notation: bool = False) -> str:
        linear_terms = self._format_term_type_into_string(self.coefs, self.vars,
                                                          use_latex_notation=use_latex_notation)

        lhs = ' '.join(linear_terms)

        predicate_symbol = self.predicate_symbol
        if use_latex_notation:
            predicate_symbol = {'<=': '\\le', '>=': '\\ge'}.get(predicate_symbol, predicate_symbol)

        return f'{lhs} {predicate_symbol} {self.rhs}'

    def __str__(self):
        return self.into_string(use_latex_notation=False)

    def __repr__(self):
        return 'Relation(' + self.into_string(use_latex_notation=False) + ')'

    def is_in_canoical_form(self) -> bool:
        positive_sign_count = sum(coef >= 0 for coef in self.coefs)
        if positive_sign_count == len(self.coefs) / 2:
            return self.rhs >= 0
        return (positive_sign_count > len(self.coefs) / 2)

    def ensure_canoical_form_if_equation(self):
        """Ensures that the majority of variables/moduloterms in the relation have the positive sign if the predicate_symbol is =."""
        if self.predicate_symbol != '=':
            return
        if not self.is_in_canoical_form():
            self.variable_coefficients = [-1 * coef for coef in self.variable_coefficients]
            self.rhs *= -1

    def sort_variables(self):
        """Sorts the variables and corresponding coefficients alphabetically."""
        var_coef_pairs = zip(self.vars, self.coefs)
        sorted_var_coef_pairs = sorted(var_coef_pairs, key=lambda pair: pair[0])

        sorted_vars, sorted_coefs = zip(*sorted_var_coef_pairs) if sorted_var_coef_pairs else (tuple(), tuple())
        self.vars = list(sorted_vars)  # type: ignore
        self.coefs = list(sorted_coefs)  # type: ignore

    @staticmethod
    def new_lin_relation(variable_names: List[Var] = [], variable_coefficients: List[int] = [],
                         absolute_part: int = 0, predicate_symbol: str = '=') -> Relation:
        return Relation(vars=variable_names, coefs=variable_coefficients, rhs=absolute_part, predicate_symbol=predicate_symbol)

    def __eq__(self, other: Relation) -> bool:
        if not isinstance(other, Relation):
            return False
        if self.predicate_symbol != other.predicate_symbol:
            return False
        if self.rhs != other.rhs:
            return False
        if len(self.vars) != len(other.vars):
            return False

        # Convert to dictionaries as want comparison regardless of variable order
        self_lin_term = {var: coef for var, coef in zip(self.vars, self.coefs)}
        other_lin_term = {var: coef for var, coef in zip(other.vars, other.coefs)}

        return self_lin_term == other_lin_term

    def is_hard_bound(self) -> bool:
        return len(self.vars) == 1 and self.predicate_symbol == '<='

    def specifies_a_single_value_for_var(self) -> bool:
        return len(self.vars) == 1 and self.predicate_symbol == '='

    def is_true_or_false(self) -> bool | None:
        all_coefs_zero = self.are_all_coefficients_zero()
        if not all_coefs_zero:
            return None

        if self.predicate_symbol == '=':
            return self.rhs == 0

        return self.rhs >= 0

    def is_unsat_eq(self) -> bool:
        if self.predicate_symbol != '=':
            return False

        gcd = math.gcd(*self.coefs)
        return (self.rhs % gcd) != 0

    def negate(self) -> Relation:
        # not(x <= 3)  <=>  x > 3   <=>  x >= 4  <=>  -x <= -4
        new_coefs = [-coef for coef in self.coefs]
        new_rhs = -self.rhs - 1

        return Relation(vars=self.vars, coefs=new_coefs, rhs=new_rhs, predicate_symbol='<=')

    def multiply_by_num(self, multiplier: int) -> Relation:
        new_relation = Relation(
            vars=list(self.vars),
            coefs=[multiplier * coef for coef in self.coefs],
            rhs=multiplier * self.rhs,
            predicate_symbol=self.predicate_symbol
        )
        return new_relation

@dataclass
class Congruence:
    """A congruence a_1 * c_1 ... = rhs (mod modulus)"""
    vars: List[Var]
    coefs: List[int]
    rhs: int
    modulus: int

    id: int = -1
    _id: int = field(default=-1, compare=False, repr=False)

    def linear_terms(self) -> Generator[Tuple[int, Var], None, None]:
        for term in zip(self.coefs, self.vars):
            yield term

    def is_normalized(self) -> bool:
        if len(self.coefs) > 1:
            return False
        return self.coefs[0] == 1

    def normalize(self) -> Congruence | None:
        if len(self.coefs) > 1:
            return None

        coef = self.coefs[0]
        try:
            coef_inv = pow(coef, -1, self.modulus)
        except ValueError:
            return None
        rhs = (self.rhs * coef_inv) % self.modulus
        return Congruence(vars=list(self.vars), coefs=[1], rhs=rhs, modulus=self.modulus)

    def with_coefficients_reduced_mod_modulus(self) -> Congruence | BoolLiteral:
        """ Return a new Congruence with every coefficient X replaced by (X mod modulus). """
        new_rhs = self.rhs % self.modulus

        new_terms = [(coef % self.modulus, var) for coef, var in self.linear_terms() if coef % self.modulus != 0]

        if not new_terms:
            return BoolLiteral(value=(new_rhs == 0))

        coefs, vars = zip(*new_terms)
        return Congruence(
            vars=list(vars),
            coefs=list(coefs),
            rhs=self.rhs,
            modulus=self.modulus,
        )

    def is_unsat(self) -> bool:
        """
        Returns True if `coefs . vars = rhs (mod modulus)` has no integer solution for any assignment
        of `vars`, e.g. `4194304*x = 1048576 (mod 2**32)` (every value the left-hand side can take is
        a multiple of gcd(4194304, 2**32) = 4194304, but 1048576 is not).

        A linear congruence is solvable over the integers iff gcd(coefs..., modulus) divides rhs -
        substitute k*modulus for the "mod modulus" part and this is exactly the classical
        Diophantine-equation solvability condition with `modulus` treated as one more coefficient
        of an unconstrained integer variable. `math.gcd(*self.coefs, self.modulus)` handles the
        no-variables case too (gcd() of an empty sequence plus `modulus` is just `modulus`).
        """
        coefs_and_modulus_gcd = math.gcd(*self.coefs, self.modulus)
        return self.rhs % coefs_and_modulus_gcd != 0


@dataclass
class BoolLiteral:
    """True or False formula"""
    value: bool
    _id: int = field(default=-1, compare=False, repr=False)

Frozen_AST = Union[int, str, Tuple['Raw_AST', ...]]
Raw_AST = Union[int, str, List['Raw_AST']]
AST_Atom = Union[str, Var, Congruence, Relation, BoolLiteral]
AST_NaryNode = List[Union[AST_Atom, 'AST_NaryNode']]
AST_Node = Union[AST_Atom, AST_NaryNode]


class AST_Node_Names(Enum):
    DECLARE_FUN = 'declare-fun'
    ASSERT = 'assert'
    CHECK_SAT = 'check-sat'
    EXISTS = 'exists'
    BOOL_EQUIV = '='
    SET_INFO = 'set-info'
    AND = 'and'
    OR = 'or'
    NOT = 'not'


def ast_get_node_type(node: AST_NaryNode) -> str:
    node_type: str = node[0]  # type: ignore
    return node_type


def ast_get_binding_list(exists_node: AST_NaryNode) -> List[Var]:
    binding_list: List[Var] = exists_node[1]  # type: ignore
    return binding_list


def make_exists_node(bound_vars: List[Var], subformula: AST_Node) -> AST_NaryNode:
    return [AST_Node_Names.EXISTS.value, list(bound_vars), subformula]  # type: ignore


def make_and_node(subformulae: List[AST_Node]) -> AST_NaryNode:
    return [AST_Node_Names.AND.value, *subformulae]


def make_or_node(subformulae: List[AST_Node]) -> AST_NaryNode:
    return [AST_Node_Names.OR.value, *subformulae]


def make_not_node(subformula: AST_Node) -> AST_NaryNode:
    return [AST_Node_Names.NOT.value, subformula]


@dataclass
class NodeEncounteredHandlerStatus:
    should_reevaluate_result: bool
    is_result_atomic: bool
    do_not_descend_further: bool = False


NodeEncounteredHandler = Callable[[AST_NaryNode, bool, Dict], NodeEncounteredHandlerStatus]


class VariableType(IntEnum):
    INT = 1
    BOOL = 2
    UNSET = 3

    @staticmethod
    def from_smt_type_string(type_str: str) -> VariableType:
        m = {
            'Bool': VariableType.BOOL,
            'Int': VariableType.INT,
        }
        return m[type_str]

    def into_smt2_sort(self) -> str:
        match self.value:
            case VariableType.INT:
                return 'Int'
            case VariableType.BOOL:
                return 'Bool'
            case _:
                raise ValueError(f'Converting unknown variable type into SMT2 sort. Type: {self}')

@dataclass
class Value_Interval:
    lower_limit: Optional[int] = None
    upper_limit: Optional[int] = None

    def __repr__(self) -> str:
        lower = self.lower_limit if self.lower_limit is not None else '-inf'
        upper = self.upper_limit if self.upper_limit is not None else '+inf'
        return f'<{lower}, {upper}>'

    def try_strengthen_lower(self, new_lower: int):
        if self.lower_limit is None:
            self.lower_limit = new_lower
        else:
            self.lower_limit = max(self.lower_limit, new_lower)

    def try_strengthen_upper(self, new_upper: int):
        if self.upper_limit is None:
            self.upper_limit = new_upper
        else:
            self.upper_limit = min(self.upper_limit, new_upper)

    def synthetize_atoms(self, var: Var) -> Tuple[Relation, ...]:
        atoms = []
        if self.lower_limit is not None:
            if self.lower_limit == self.upper_limit:
                return (Relation(vars=[var], coefs=[1], rhs=self.lower_limit, predicate_symbol='='),)

            lower_limit = Relation(vars=[var], coefs=[-1], rhs=-self.lower_limit, predicate_symbol='<=')
            atoms.append(lower_limit)
        if self.upper_limit is not None:
            upper_limit = Relation(vars=[var], coefs=[1], rhs=self.upper_limit, predicate_symbol='<=')
            atoms.append(upper_limit)
        return tuple(atoms)

    def implies_contradiction(self) -> bool:
        if self.lower_limit is None or self.upper_limit is None:
            return False

        return self.upper_limit < self.lower_limit

    def apply_assertion(self, assertion: Relation):
        if assertion.is_hard_bound():
            bound_type, _, bound_val = get_hard_bound_semantics(assertion)
            if bound_type == Bound_Type.LOWER:
                self.try_strengthen_lower(bound_val)
            else:
                self.try_strengthen_upper(bound_val)
        elif assertion.specifies_a_single_value_for_var():
            implied_val = assertion.rhs // assertion.coefs[0]
            self.try_strengthen_lower(implied_val)
            self.try_strengthen_upper(implied_val)

    def copy(self) -> Value_Interval:
        return Value_Interval(self.lower_limit, self.upper_limit)


@dataclass
class FunctionSymbol:
    name: str
    arity: int
    args: List[Tuple[str, VariableType]]
    return_type: VariableType


@dataclass
class ASTp_Node_Base:
    referenced_vars: Tuple[Var,...] = field(repr=True, compare=False)


@dataclass
class AST_Negation(ASTp_Node_Base):
    child: ASTp_Node
    _id: int = field(default=-1, compare=False, repr=False)


@dataclass
class AST_Quantifier(ASTp_Node_Base):
    bound_vars: Tuple[Var, ...]
    child: ASTp_Node
    _id: int = field(default=-1, compare=False, repr=False)


class Connective_Type(IntEnum):
    AND   = 0x01
    OR    = 0x02
    EQUIV = 0x03


@dataclass
class AST_Connective(ASTp_Node_Base):
    type: Connective_Type
    children: Tuple[ASTp_Node, ...]
    variable_bounds: Optional[Dict[Var, Value_Interval]] = field(default=None, repr=False)
    _id: int = field(default=-1, compare=False, repr=False)

    def replace_children(self, new_children: Tuple[ASTp_Node, ...]) -> AST_Connective:
        return AST_Connective(referenced_vars=self.referenced_vars,
                              type=self.type,
                              children=new_children,
                              variable_bounds=self.variable_bounds)

    def remove_idempotent_children(self) -> ASTp_Node:
        if self.type == Connective_Type.EQUIV:
            return self

        idempotent_child = BoolLiteral(False) if self.type == Connective_Type.OR else BoolLiteral(True)

        new_children = tuple(child for child in self.children if child != idempotent_child)

        if not new_children:
            return idempotent_child

        if len(new_children) == 1:
            return new_children[0]

        return self.replace_children(new_children)

    def simplify_on_anihilators(self) -> AST_Connective | BoolLiteral:
        if self.type == Connective_Type.EQUIV:
            return self

        anihilator = BoolLiteral(True) if self.type == Connective_Type.OR else BoolLiteral(False)

        if any(child == anihilator for child in self.children):
            return anihilator

        return self

    def simplify_on_exclusion_on_the_third(self) -> AST_Connective | BoolLiteral:
        """
        Simplify formulae such as (AND X (NOT X)) whre X is a Bool var. 

        This is implemented for Bool vars so far.

        @Todo: Extend this to arbitrary formulae once we implement second-order term labeling (formulae IDs)
        """

        positive_vars: set[Var] = set()
        negative_vars: set[Var] = set()

        for child in self.children:
            if isinstance(child, Var):
                positive_vars.add(child)
                continue

            if isinstance(child, AST_Negation):
                if isinstance(child.child, Var):
                    negative_vars.add(child.child)

        vars_appearing_with_both_polarities = positive_vars & negative_vars

        if vars_appearing_with_both_polarities:
            # (and p (not p)) is False, (or p (not p)) is True; EQUIV left alone.
            if self.type == Connective_Type.AND:
                return BoolLiteral(False)
            if self.type == Connective_Type.OR:
                return BoolLiteral(True)
            return self

        return self
                       

ASTp_Leaf_Type_List = (Relation, Congruence, BoolLiteral, Var)
ASTp_Node = Union[AST_Connective, AST_Negation, AST_Quantifier, Relation, Congruence, BoolLiteral, Var]


def ast_references_var(root_node: ASTp_Node, var: Var) -> bool:
    """
    Check whether `var` still occurs in `root_node`.

    Recomputes the answer directly from the tree instead of trusting a `referenced_vars` field or a
    variable-use count gathered before some subtree was simplified away - a node's cached
    `referenced_vars` can go stale once its children are rewritten (e.g. `AST_Connective.replace_children`
    keeps the original value), and a pre-simplification usage count does not tell you whether the atom
    that used the variable actually got dropped by the simplification.
    """
    match root_node:
        case Var():
            return root_node == var
        case BoolLiteral():
            return False
        case Relation() | Congruence():
            return var in root_node.vars
        case AST_Connective():
            return any(ast_references_var(child, var) for child in root_node.children)
        case AST_Negation() | AST_Quantifier():
            return ast_references_var(root_node.child, var)
        case _:
            raise ValueError(f'Unhandled node type when checking variable references: {type(root_node)} :: {root_node}')


def format_formula(ast: ASTp_Node, indent: int = 0) -> str:
    """ Same tree layout as `pprint_formula`, returned as a string instead of printed directly. """
    indent_str = '   ' * indent
    match ast:
        case BoolLiteral() | Relation() | Congruence() | Var():
            return f'{indent_str}{ast}'
        case AST_Connective():
            connective_symbol_table = {
                Connective_Type.AND:   'and',
                Connective_Type.OR:    'or',
                Connective_Type.EQUIV: '<=>'
            }
            symbol = connective_symbol_table[ast.type]
            lines = [f'{indent_str}{symbol}']
            lines.extend(format_formula(child, indent=indent+1) for child in ast.children)
            return '\n'.join(lines)
        case AST_Negation():
            return f'{indent_str}NOT\n' + format_formula(ast.child, indent=indent+1)
        case AST_Quantifier():
            var_list = ','.join(f'{var}' for var in ast.bound_vars)
            return f'{indent_str}exists ({var_list})\n' + format_formula(ast.child, indent=indent+1)
        case _:
            raise NotImplementedError(f'Unhandled node while formatting formula: {ast=}')


def pprint_formula(ast: ASTp_Node, indent: int = 0):
    print(format_formula(ast, indent=indent))


class Bound_Type(IntEnum):
    LOWER = 0x01
    UPPER = 0x02


def get_hard_bound_semantics(rel: Relation) -> Tuple[Bound_Type, Var, int]:
    var, coef = rel.vars[0], rel.coefs[0]
    if coef < 0:
        implied_val = -(-rel.rhs // coef)  # ceil(rhs / coef), exact for integers of any size
        bound_type = Bound_Type.LOWER
    else:
        implied_val = rel.rhs // coef  # floor(rhs / coef)
        bound_type = Bound_Type.UPPER

    return (bound_type, var, implied_val)


def compute_implied_bound(var: Var, coef: int, bound_rhs: int) -> int:
    if coef < 0:
        return -(-bound_rhs // coef)  # ceil(bound_rhs / coef), exact for integers of any size
    return bound_rhs // coef  # floor(bound_rhs / coef)


def unzip_lin_terms(terms: Iterable[Tuple[int, Var]]) -> Tuple[List[int], List[Var]]:
    vars, coefs = [], []
    for coef, var in terms:
        vars.append(var)
        coefs.append(coef)
    return coefs, vars
