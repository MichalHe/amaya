from __future__ import annotations
from collections import defaultdict
from dataclasses import (
    dataclass,
    field
)
import functools
import math
import itertools
from math import gcd
from typing import (
    Any,
    Dict,
    FrozenSet,
    Iterable,
    List,
    Optional,
    Set,
    Tuple,
    Union,
    cast,
)
from amaya.preprocessing.eval import LinTerm, Scoper, VarInfo, split_lin_terms_into_vars_and_coefs

from amaya.relations_structures import (
    AST_Connective,
    AST_Negation,
    AST_Quantifier,
    ASTp_Node,
    BoolLiteral,
    Bound_Type,
    Congruence,
    Connective_Type,
    Relation,
    Var,
    VariableType,
    Value_Interval,
    ast_references_var,
    get_hard_bound_semantics,
    pprint_formula,
    unzip_lin_terms,
)

from amaya import logger
from amaya.config import solver_config


@dataclass
class AST_Internal_Node_With_Bounds_Info:
    node_type: str
    children: List[AST_Node_With_Bounds_Info]
    var_values: Dict[Var, List[Value_Interval]] = field(default_factory=lambda: defaultdict(lambda: [Value_Interval(None, None)]))


@dataclass
class AST_Quantifier_Node_With_Bounds_Info:
    node_type: str
    child: AST_Node_With_Bounds_Info
    bindings: List[Var]
    var_values: Dict[Var, List[Value_Interval]] = field(default_factory=lambda: defaultdict(lambda: [Value_Interval(None, None)]))


@dataclass
class AST_Leaf_Node_With_Bounds_Info:
    contents: Union[Relation, Congruence, Var, BoolLiteral]
    var_values: Dict[Var, List[Value_Interval]] = field(default_factory=lambda: defaultdict(lambda: [Value_Interval(None, None)]))


AST_Node_With_Bounds_Info = Union[AST_Leaf_Node_With_Bounds_Info, AST_Quantifier_Node_With_Bounds_Info, AST_Internal_Node_With_Bounds_Info]


def make_value_interval_intersection(left_intervals: List[Value_Interval], right_intervals: List[Value_Interval]):
    if not left_intervals or not right_intervals:
        return []

    def _max(a, b):
        if a is None:
            return b
        if b is None:
            return a
        return max(a, b)

    def _min(a, b):
        if a is None:
            return b
        if b is None:
            return a
        return min(a, b)

    result: List[Value_Interval] = []
    left_idx = 0
    right_idx = 0

    while left_idx < len(left_intervals) and right_idx < len(right_intervals):
        left = left_intervals[left_idx]
        right = right_intervals[right_idx]

        lower = _max(left.lower_limit, right.lower_limit)
        upper = _min(left.upper_limit, right.upper_limit)

        if upper == left.upper_limit:
            left_idx += 1
        else:
            right_idx += 1

        if lower is None or upper is None or lower <= upper:
            result.append(Value_Interval(lower, upper))

    return result


def _make_value_interval_union(left_intervals: List[Value_Interval], right_intervals: List[Value_Interval]) -> List[Value_Interval]:
    intervals = left_intervals + right_intervals
    min_lower_bound = None

    for interval in intervals:
        if interval.lower_limit is not None:
            min_lower_bound = min(min_lower_bound, interval.lower_limit) if min_lower_bound else interval.lower_limit

    if min_lower_bound is None:
        min_lower_bound = 0
    else:
        min_lower_bound = -1

    def get_lower_bound(interval: Value_Interval) -> int:
        if interval.lower_limit is None:
            return min_lower_bound
        return interval.lower_limit

    intervals = sorted(intervals, key=get_lower_bound)

    interval_union = []
    current_interval = intervals[0]
    for interval in intervals[1:]:
        if current_interval.upper_limit is None:
            interval_union.append(current_interval)
            return interval_union

        # The intervals are sorted by their lower limits, therefore, the `current_interval`
        # also has lower limit = -inf
        if interval.lower_limit is None:
            if interval.upper_limit is None:
                current_interval = Value_Interval()
                continue  # We will return in the next iteration either way

            old_val: int = current_interval.upper_limit
            new_val: int = interval.upper_limit
            current_interval.upper_limit = max(old_val, new_val)
            continue

        if interval.lower_limit <= current_interval.upper_limit:  # The intervals overlap
            if interval.upper_limit is None:
                current_interval.upper_limit = None
            else:
                current_interval.upper_limit = max(current_interval.upper_limit, interval.upper_limit)
        else: # The intervals do not overlap
            interval_union.append(current_interval)
            current_interval = interval

    return interval_union


def make_value_interval_union(left_intervals: List[Value_Interval], right_intervals: List[Value_Interval]):
    intervals = sorted((iv.copy() for iv in itertools.chain(left_intervals, right_intervals)),
                       key=lambda iv: (iv.lower_limit is not None, iv.lower_limit or 0))
    result: List[Value_Interval] = []
    for iv in intervals:
        if result:
            last = result[-1]
            if last.upper_limit is None:
                break
            if iv.lower_limit is None or iv.lower_limit <= last.upper_limit + 1:
                last.upper_limit = None if iv.upper_limit is None else max(last.upper_limit, iv.upper_limit)
                continue
        result.append(iv)
    return result


def make_value_interval_negation(intervals: List[Value_Interval]) -> List[Value_Interval]:
    if not intervals:
        return [Value_Interval(lower_limit=None, upper_limit=None)]

    result = []

    if intervals[0].lower_limit is not None:
        result.append(Value_Interval(lower_limit=None, upper_limit=intervals[0].lower_limit - 1))

    for i in range(len(intervals)-1):
        start = intervals[i].upper_limit + 1  # type: ignore
        end = intervals[i+1].lower_limit - 1  # type: ignore
        if start <= end:  # adjacent intervals (e.g. <-inf,3>, <4,+inf>) leave no gap
            result.append(Value_Interval(lower_limit=start, upper_limit=end))

    if intervals[-1].upper_limit is not None:
        result.append(Value_Interval(lower_limit=intervals[-1].upper_limit + 1, upper_limit=None))

    return result


def perform_variable_bounds_analysis_on_ast(ast: ASTp_Node) -> AST_Node_With_Bounds_Info:
    if isinstance(ast, Relation):
        relation: Relation = ast
        bounds_info = AST_Leaf_Node_With_Bounds_Info(contents=relation)

        if len(relation.vars) == 1 and relation.coefs[0] != 0:
            var, coef = relation.vars[0], relation.coefs[0]

            if relation.predicate_symbol == '=':
                if relation.rhs % coef != 0:
                    # e.g. 7x = 1: no integer value. An empty list of intervals keeps the relation from
                    # being replaced by bounds (see `_simplify_bounded_atoms`), so it is evaluated as is.
                    bounds_info.var_values[var] = []
                else:
                    value = relation.rhs // coef
                    bounds_info.var_values[var] = [Value_Interval(value, value)]
            elif relation.predicate_symbol == '<=':
                value_interval = Value_Interval()
                if coef > 0:
                    value_interval.upper_limit = relation.rhs // coef        # c*x <= k  <->  x <= floor(k/c)
                else:
                    value_interval.lower_limit = -(relation.rhs // -coef)    # c*x <= k, c < 0  <->  x >= ceil(k/c)
                bounds_info.var_values[var] = [value_interval]
        else:
            for var in relation.vars:
                bounds_info.var_values[var] = [Value_Interval(None, None)]
        return bounds_info

    elif isinstance(ast, (Congruence, BoolLiteral, Var)):
        return AST_Leaf_Node_With_Bounds_Info(contents=ast)

    elif isinstance(ast, AST_Quantifier):
        subtree_bounds_info = perform_variable_bounds_analysis_on_ast(ast.child)

        quantified_vars: Set[Var] = set(ast.bound_vars)
        var_values: Dict[Var, List[Value_Interval]] = {}
        for var, var_value_intervals in subtree_bounds_info.var_values.items():
            new_var_value_intervals = [Value_Interval(None, None)] if var in quantified_vars else var_value_intervals
            var_values[var] = new_var_value_intervals

        quantifier_node_with_bounds_info = AST_Quantifier_Node_With_Bounds_Info(node_type='exists',
                                                                                child=subtree_bounds_info,
                                                                                bindings=list(ast.bound_vars),
                                                                                var_values=var_values)
        return quantifier_node_with_bounds_info

    elif isinstance(ast, AST_Connective) and ast.type == Connective_Type.AND:
        subtrees_with_bounds = [perform_variable_bounds_analysis_on_ast(subtree) for subtree in ast.children]

        overall_bounds_info = AST_Internal_Node_With_Bounds_Info(node_type='and', children=subtrees_with_bounds)
        for subtree_with_bounds in subtrees_with_bounds:
            for var, var_value_intervals in subtree_with_bounds.var_values.items():
                overall_bounds_info.var_values[var] = make_value_interval_intersection(overall_bounds_info.var_values[var],
                                                                                       var_value_intervals)
        return overall_bounds_info

    elif isinstance(ast, AST_Connective) and ast.type == Connective_Type.OR:
        subtrees_with_bounds = [perform_variable_bounds_analysis_on_ast(subtree) for subtree in ast.children]

        overall_bounds_info = AST_Internal_Node_With_Bounds_Info(node_type='or', children=subtrees_with_bounds)
        overall_bounds_info.var_values = defaultdict(list)
        seen_vars: Dict[Var, int] = defaultdict(int)

        for subtree_with_bounds in subtrees_with_bounds:
            for var, bounds_info in subtree_with_bounds.var_values.items():
                overall_bounds_info.var_values[var] = make_value_interval_union(overall_bounds_info.var_values[var],
                                                                                bounds_info)
                seen_vars[var] += 1

        for seen_var, seen_cnt in seen_vars.items():
            if seen_cnt < len(subtrees_with_bounds):
                overall_bounds_info.var_values[seen_var] = [Value_Interval()]

        return overall_bounds_info

    elif isinstance(ast, AST_Negation):
        subtree_bounds_info = perform_variable_bounds_analysis_on_ast(ast.child)
        negated_var_values: Dict[Var, List[Value_Interval]] = {}

        if isinstance(ast.child, Relation) and len(ast.child.vars) == 1 and len(subtree_bounds_info.var_values) == 1:
            for var, bounds in subtree_bounds_info.var_values.items():
                negated_var_values[var] = make_value_interval_negation(bounds)
        else:
            negated_var_values = {var: [Value_Interval(None, None)] for var in subtree_bounds_info.var_values}

        return AST_Internal_Node_With_Bounds_Info(node_type='not',
                                                  children=[subtree_bounds_info],
                                                  var_values=negated_var_values)

    elif isinstance(ast, AST_Connective) and ast.type == Connective_Type.EQUIV:
        subtree_bounds_info = [perform_variable_bounds_analysis_on_ast(child) for child in ast.children]
        return AST_Internal_Node_With_Bounds_Info(node_type='=',
                                                  children=subtree_bounds_info)

    raise ValueError(f'[Variable bounds analysis] Cannot descend into AST - unknown node: {ast=}')


def filter_vars_with_no_info_from_node(vars_with_bounds_rewritten: Set[Var], node: AST_Internal_Node_With_Bounds_Info) -> Set[Var]:
    vars_with_no_info_about_their_value: Set[Var] = set()

    for var in vars_with_bounds_rewritten:
        var_values = node.var_values.get(var, [Value_Interval()])

        if len(var_values) != 1:
            continue

        value_interval = var_values[0]
        if value_interval.lower_limit is None and value_interval.upper_limit is None:
            vars_with_no_info_about_their_value.add(var)

    return vars_with_bounds_rewritten.difference(vars_with_no_info_about_their_value)


def _simplify_bounded_atoms(ast: AST_Node_With_Bounds_Info, vars_with_rewritten_bounds: Set[Var]) -> Optional[ASTp_Node]:
    if isinstance(ast, AST_Leaf_Node_With_Bounds_Info):
        if isinstance(ast.contents, (Var, Congruence, BoolLiteral)):
            return ast.contents

        relation: Relation = ast.contents
        if len(relation.vars) == 1:
            # The current relation represents a bound on a single variable
            bound_for_var = relation.vars[0]
            if bound_for_var in vars_with_rewritten_bounds:
                return None
        return relation

    if isinstance(ast, AST_Internal_Node_With_Bounds_Info):
        if ast.node_type == 'and':
            # At the current level we want to rewrite bounds only for those variables that will
            # not have their bounds rewritten at some upper level
            vars_to_rewrite_bounds_at_current_level: Set[Var] = set()
            for var, bound_info in ast.var_values.items():
                if len(bound_info) == 1 and var not in vars_with_rewritten_bounds:
                    bound = bound_info[0]
                    if bound.lower_limit is None and bound.upper_limit is None:
                        continue
                    vars_to_rewrite_bounds_at_current_level.add(var)

            new_children: List[ASTp_Node] = []
            for var_to_rewrite_bounds in vars_to_rewrite_bounds_at_current_level:
                var_bounds = ast.var_values[var_to_rewrite_bounds][0]
                are_bounds_equal = var_bounds.lower_limit == var_bounds.upper_limit
                if var_bounds.lower_limit is not None:
                    if are_bounds_equal:  # Both of the bounds have value (!= None)
                        eq = Relation(vars=[var_to_rewrite_bounds], coefs=[1], predicate_symbol='=', rhs=var_bounds.lower_limit)
                        new_children.append(eq)
                        continue

                    lower_bound = Relation.new_lin_relation(variable_names=[var_to_rewrite_bounds], variable_coefficients=[-1],
                                                            predicate_symbol='<=', absolute_part=-var_bounds.lower_limit)
                    new_children.append(lower_bound)
                if var_bounds.upper_limit is not None:
                    upper_bound = Relation.new_lin_relation(variable_names=[var_to_rewrite_bounds], variable_coefficients=[1],
                                                            predicate_symbol='<=', absolute_part=var_bounds.upper_limit)
                    new_children.append(upper_bound)

            vars_to_not_rewrite_at_lower_levels = vars_to_rewrite_bounds_at_current_level.union(vars_with_rewritten_bounds)
            for subtree in ast.children:
                simplified_subtree = _simplify_bounded_atoms(subtree, vars_to_not_rewrite_at_lower_levels)
                if simplified_subtree:
                    new_children.append(simplified_subtree)

            if not new_children:
                return None
            children = tuple(new_children)
            return AST_Connective(referenced_vars=_referenced_vars_of_children(children), type=Connective_Type.AND, children=children)

        elif ast.node_type == 'not':
            vars_to_not_rewrite = filter_vars_with_no_info_from_node(vars_with_rewritten_bounds, ast)
            simplified_child = _simplify_bounded_atoms(ast.children[0], vars_to_not_rewrite)
            if not simplified_child:
                return None
            return AST_Negation(referenced_vars=_referenced_vars_of(simplified_child), child=simplified_child)

        else:  # 'or' or '=' (Boolean equivalence)
            connective_type = Connective_Type.OR if ast.node_type == 'or' else Connective_Type.EQUIV
            # The ancestor's bound is (union over branches) /\ (siblings); it does not imply a branch-local
            # bound, so the atoms of the branches must be kept.
            vars_to_not_rewrite = set()
            rewritten_subtrees = (_simplify_bounded_atoms(subtree, vars_to_not_rewrite) for subtree in ast.children)
            preserved_subtrees = tuple(tree for tree in rewritten_subtrees if tree)
            if not preserved_subtrees:
                return None
            return AST_Connective(referenced_vars=_referenced_vars_of_children(preserved_subtrees), type=connective_type, children=preserved_subtrees)

    if isinstance(ast, AST_Quantifier_Node_With_Bounds_Info):
        rewritten_subtree = _simplify_bounded_atoms(ast.child, vars_with_rewritten_bounds)

        assert_msg = ('The entire subtree under a quantifier has been factored out, meaning the quantifier has no semantic value?'
                      ' More likely are doing something wrong.')

        assert rewritten_subtree, assert_msg
        return AST_Quantifier(referenced_vars=_referenced_vars_of(rewritten_subtree), bound_vars=tuple(ast.bindings), child=rewritten_subtree)

    raise ValueError(f'Don\'t know how to process the node {ast=} when simplifying variable bounds.')


def _fmt_bound_analysis_tree_into_str(ast: AST_Node_With_Bounds_Info, depth: int) -> List[str]:
    prefix = '  '*depth
    if isinstance(ast, AST_Quantifier_Node_With_Bounds_Info):
        result = [f'{prefix}{ast.node_type}{ast.bindings}']
        result += _fmt_bound_analysis_tree_into_str(ast.child, depth+1)
        return result
    if isinstance(ast, AST_Internal_Node_With_Bounds_Info):
        result = [f'{prefix}{ast.node_type}  :: {dict(ast.var_values)}']
        for child in ast.children:
            result += _fmt_bound_analysis_tree_into_str(child, depth+1)
        return result
    if isinstance(ast, AST_Leaf_Node_With_Bounds_Info):
        return [f'{prefix}{ast.contents}']


def fmt_bound_analysis_tree_into_str(ast):
    return '\n'.join(_fmt_bound_analysis_tree_into_str(ast, 0))


def simplify_bounded_atoms(ast: ASTp_Node) -> Optional[ASTp_Node]:
    ast_with_bounds = perform_variable_bounds_analysis_on_ast(ast)
    simplified_tree = _simplify_bounded_atoms(ast_with_bounds, set())
    return simplified_tree


def _simplify_unbounded_equations(ast: ASTp_Node) -> ASTp_Node:
    if is_atom(ast):
        return ast

    match ast:
        case AST_Quantifier():
            if isinstance(ast.child, Relation) and ast.child.predicate_symbol == '=':
                bound_vars: Tuple[Var, ...] = ast.bound_vars
                rel: Relation = ast.child

                bound_var_coefs: List[int] = []
                remaining_lin_terms: List[Tuple[Var, int]] = []
                for var, coef in zip(rel.vars, rel.coefs):
                    if var in bound_vars:
                        bound_var_coefs.append(coef)
                        continue
                    remaining_lin_terms.append((var, coef))
                remaining_lin_terms = sorted(remaining_lin_terms, key = lambda var_coef_pair: var_coef_pair[0])

                if not bound_var_coefs:  # no quantified var occurs in the equation (e.g. it cancelled out)
                    return rel

                if not remaining_lin_terms:
                    return BoolLiteral(value=(rel.rhs % gcd(*bound_var_coefs) == 0))

                vars, coefs = [], []
                for var, coef in remaining_lin_terms:
                    vars.append(var)
                    coefs.append(coef)


                modulus = gcd(*bound_var_coefs)
                rhs = rel.rhs % modulus
                congruence = Congruence(vars=list(vars), coefs=list(coefs), rhs=rhs, modulus=modulus)
                return congruence
            return AST_Quantifier(referenced_vars=ast.referenced_vars, bound_vars=ast.bound_vars,
                                  child=_simplify_unbounded_equations(ast.child))

        case AST_Negation():
            return AST_Negation(referenced_vars=ast.referenced_vars, child=_simplify_unbounded_equations(ast.child))

        case AST_Connective():
            children = tuple(_simplify_unbounded_equations(child) for child in ast.children)
            return ast.replace_children(children)

    raise NotImplementedError(f'Unhandled node while simplifying unbounded equations: {ast=}')


def simplify_unbounded_equations(ast: ASTp_Node) -> ASTp_Node:
    return _simplify_unbounded_equations(ast)


def _referenced_vars_of(ast: ASTp_Node) -> Tuple[Var, ...]:
    match ast:
        case Var():
            return (ast,)
        case Relation() | Congruence():
            return tuple(ast.vars)
        case BoolLiteral():
            return tuple()
        case _:
            return ast.referenced_vars


def drop_negation_if_holding(ast: ASTp_Node, holding_negation: bool) -> ASTp_Node:
    if not holding_negation:
        return ast
    return AST_Negation(referenced_vars=_referenced_vars_of(ast), child=ast)


def _push_negations_towards_atoms(ast: ASTp_Node, holding_negation: bool) -> ASTp_Node:
    match ast:
        case Var():
            return drop_negation_if_holding(ast, holding_negation)

        case Relation():
            if ast.predicate_symbol == '=':
                return drop_negation_if_holding(ast, holding_negation)
            if not holding_negation:
                return ast
            assert ast.predicate_symbol == '<='
            negated_coefs = [-coef for coef in ast.coefs]
            rhs = -(ast.rhs + 1)
            return Relation(vars=ast.vars, coefs=negated_coefs, rhs=rhs, predicate_symbol='<=')

        case Congruence():
            return drop_negation_if_holding(ast, holding_negation)

        case BoolLiteral():
            return BoolLiteral(value=not ast.value) if holding_negation else ast

        case AST_Quantifier():
            if holding_negation:
                child = _push_negations_towards_atoms(ast.child, False)
                negated_quantifier = AST_Quantifier(referenced_vars=ast.referenced_vars, bound_vars=ast.bound_vars, child=child)
                return AST_Negation(referenced_vars=ast.referenced_vars, child=negated_quantifier)
            return AST_Quantifier(referenced_vars=ast.referenced_vars, bound_vars=ast.bound_vars,
                                  child=_push_negations_towards_atoms(ast.child, holding_negation))

        case AST_Connective() if ast.type in (Connective_Type.AND, Connective_Type.OR):
            flipped_type = {Connective_Type.AND: Connective_Type.OR, Connective_Type.OR: Connective_Type.AND}
            res_type = flipped_type[ast.type] if holding_negation else ast.type
            children = tuple(_push_negations_towards_atoms(child, holding_negation) for child in ast.children)
            return AST_Connective(referenced_vars=ast.referenced_vars, type=res_type, children=children)

        case AST_Negation():
            return _push_negations_towards_atoms(ast.child, not holding_negation)

        case AST_Connective():  # Connective_Type.EQUIV
            return drop_negation_if_holding(ast, holding_negation)

    raise ValueError(f'Unhandled node type while pushing negation towards atoms: {ast=}')


def push_negations_towards_atoms(ast: ASTp_Node) -> ASTp_Node:
    """
    Push negations towards atom.

    Example:
        (not (and X (exists Z (Y (Z)))))   --->    (or (not X) (not (exists Z (Y (Z)))))
    """
    result = _push_negations_towards_atoms(ast, holding_negation=False)
    return result


@dataclass
class Var_Use_Info:
    vars_in_positive_atoms: dict[Var, int] = field(default_factory=lambda: defaultdict(int))
    vars_in_disequalities: dict[Var, int] = field(default_factory=lambda: defaultdict(int))
    existentially_quantified_vars: Set[Var] = field(default_factory=set)

    def add_positive_atom_variable_use(self, var: Var):
        self.vars_in_positive_atoms[var] += 1

    def add_var_use_in_disequality(self, var: Var):
        self.vars_in_disequalities[var] += 1

    def is_var_inconsequential_to_models(self, var: Var) -> bool:
        positive_atom_uses = self.vars_in_positive_atoms[var]
        disequation_uses = self.vars_in_disequalities[var]

        if var not in self.existentially_quantified_vars:
            return False  # free variables are constrained by the caller's context

        is_var_used_only_in_diseqs = (positive_atom_uses == 0) and disequation_uses > 0
        return is_var_used_only_in_diseqs

    def contains_any_data(self) -> bool:
        return bool(self.vars_in_disequalities) or bool(self.vars_in_disequalities)


def _collect_vars_uses_for_quantifier_simplifications(ast: ASTp_Node, var_use_info: Var_Use_Info) -> None:
    match ast:
        case Var() | BoolLiteral():
            pass
        case Relation() | Congruence():
            for var in ast.vars:
                var_use_info.add_positive_atom_variable_use(var)
        case AST_Negation():
            if isinstance(ast.child, Relation) and ast.child.predicate_symbol == '=':
                for var in ast.child.vars:
                    var_use_info.add_var_use_in_disequality(var)
                return

            _collect_vars_uses_for_quantifier_simplifications(ast.child, var_use_info)
        case AST_Quantifier():
            var_use_info.existentially_quantified_vars.update(ast.bound_vars)
            _collect_vars_uses_for_quantifier_simplifications(ast.child, var_use_info)
        case AST_Connective():
            for child in ast.children:
                _collect_vars_uses_for_quantifier_simplifications(child, var_use_info)
        case _:
            raise NotImplementedError(f'Unhandled node while collecting vars used only in disequalities: {ast=}')


def _drop_vars_with_no_consequences_to_models(ast: ASTp_Node, var_use_info: Var_Use_Info) -> ASTp_Node:
    match ast:
        case Var() | BoolLiteral():
            return ast

        case Relation():
            if any(var_use_info.is_var_inconsequential_to_models(var) for var in ast.vars):
                return BoolLiteral(value=True)
            return ast

        case Congruence():
            return ast

        case AST_Negation():
            if isinstance(ast.child, Relation):
                if any(var_use_info.is_var_inconsequential_to_models(var) for var in ast.child.vars):
                    return BoolLiteral(True)  # Return true as this disequation can be always satisfied

            new_child = _drop_vars_with_no_consequences_to_models(ast.child, var_use_info)
            if isinstance(new_child, BoolLiteral):
                return BoolLiteral(value=not new_child.value)
            return AST_Negation(referenced_vars=_referenced_vars_of(new_child), child=new_child)

        case AST_Quantifier():
            new_child = _drop_vars_with_no_consequences_to_models(ast.child, var_use_info)
            new_bound_vars = tuple(var for var in ast.bound_vars if ast_references_var(new_child, var))
            if not new_bound_vars:
                return new_child
            return AST_Quantifier(referenced_vars=_referenced_vars_of(new_child), bound_vars=tuple(new_bound_vars),
                                  child=new_child)

        case AST_Connective():
            new_children = tuple(_drop_vars_with_no_consequences_to_models(child, var_use_info) for child in ast.children)
            result = ast.replace_children(new_children)
            result = result.simplify_on_anihilators()
            if not isinstance(result, AST_Connective):
                return result
            return result.remove_idempotent_children()

    raise NotImplementedError(f'Unhandled node while dropping vars used only in disequalities: {ast=}')


def remove_vars_with_no_consequences_on_the_model(ast: ASTp_Node, var_table: Dict[Var, VarInfo]) -> ASTp_Node:
    """
    Drop existentially quantified variables of an infinite sort (Int) that occur only in disequalities.

    If a quantified variable only ever appears in atoms of the form `var != C` (for some linear term C,
    possibly containing other variables), the quantifier binding it is always satisfiable - only finitely
    many values are excluded by such atoms, and the variable's domain is infinite - so the binding can be
    dropped together with the disequalities themselves, which are replaced by True.

    Example:
        (exists ((x Int)) (and (<= y 0) (not (= x 5)) (not (= x y))))   --->   (<= y 0)
    """
    var_use_info = Var_Use_Info()
    _collect_vars_uses_for_quantifier_simplifications(ast, var_use_info)

    if not var_use_info.vars_in_disequalities:
        return ast

    result = _drop_vars_with_no_consequences_to_models(ast, var_use_info)

    return result


@dataclass
class Bool_Var_Definitions:
    """ Maps a Bool var to the formula that unconditionally defines it, e.g. `b = (or x y)` maps `b -> (or x y)`. """
    definitions: dict[Var, ASTp_Node] = field(default_factory=dict)
    conflicting_vars: set[Var] = field(default_factory=set)
    defining_node_ids: set[int] = field(default_factory=set)
    """ `id()` of the AST_Connective nodes the definitions were extracted from - to be dropped once inlined. """


def _try_register_bool_var_definition(defining_node: AST_Connective, var_side: ASTp_Node, def_side: ASTp_Node,
                                      defs: Bool_Var_Definitions) -> None:
    if not isinstance(var_side, Var) or isinstance(def_side, Var):
        return

    var = var_side
    if var in defs.conflicting_vars or var in _referenced_vars_of(def_side):
        return

    if var in defs.definitions:
        if defs.definitions[var] != def_side:
            # Conflicting definitions for the same var - cannot be soundly inlined, forget about it.
            del defs.definitions[var]
            defs.conflicting_vars.add(var)
        return

    defs.definitions[var] = def_side
    defs.defining_node_ids.add(id(defining_node))


def _collect_bool_var_definitions(ast: ASTp_Node, defs: Bool_Var_Definitions) -> None:
    """
    Collect Bool var definitions reachable from `ast` through ANDs/quantifiers only - such definitions hold
    unconditionally, throughout the whole formula. Definitions nested under an OR/EQUIV only hold within that
    branch and are therefore not collected.
    """
    match ast:
        case Var() | BoolLiteral() | Relation() | Congruence() | AST_Negation():
            pass

        case AST_Quantifier():
            _collect_bool_var_definitions(ast.child, defs)

        case AST_Connective():
            if ast.type == Connective_Type.EQUIV and len(ast.children) == 2:
                left, right = ast.children
                _try_register_bool_var_definition(ast, left, right, defs)
                _try_register_bool_var_definition(ast, right, left, defs)

            if ast.type == Connective_Type.AND:
                for child in ast.children:
                    _collect_bool_var_definitions(child, defs)

        case _:
            raise NotImplementedError(f'Unhandled node while collecting bool var definitions: {ast=}')


def _resolve_bool_var_definition(var: Var, defs: Bool_Var_Definitions, cache: Dict[Var, ASTp_Node],
                                 vars_being_resolved: Set[Var]) -> ASTp_Node:
    if var in cache:
        return cache[var]

    if var in vars_being_resolved:
        # A cyclic chain of definitions, e.g. `a <=> b`, `b <=> a` - leave the var as-is to avoid looping forever.
        return var

    vars_being_resolved.add(var)
    resolved = _inline_bool_var_definitions(defs.definitions[var], defs, cache, vars_being_resolved)
    vars_being_resolved.discard(var)

    cache[var] = resolved
    return resolved


def _inline_bool_var_definitions(ast: ASTp_Node, defs: Bool_Var_Definitions, cache: Dict[Var, ASTp_Node],
                                 vars_being_resolved: Set[Var]) -> ASTp_Node:
    match ast:
        case Var():
            if ast not in defs.definitions:
                return ast
            return _resolve_bool_var_definition(ast, defs, cache, vars_being_resolved)

        case BoolLiteral() | Relation() | Congruence():
            return ast

        case AST_Connective():
            if id(ast) in defs.defining_node_ids:
                # The equivalence has become a tautology now that the var it defines has been substituted away.
                return BoolLiteral(True)

            new_children = tuple(
                _inline_bool_var_definitions(child, defs, cache, vars_being_resolved) for child in ast.children
            )
            return AST_Connective(referenced_vars=_referenced_vars_of_children(new_children), type=ast.type,
                                  children=new_children)

        case AST_Negation():
            new_child = _inline_bool_var_definitions(ast.child, defs, cache, vars_being_resolved)
            if isinstance(new_child, BoolLiteral):
                return BoolLiteral(value=not new_child.value)
            return AST_Negation(referenced_vars=_referenced_vars_of(new_child), child=new_child)

        case AST_Quantifier():
            new_child = _inline_bool_var_definitions(ast.child, defs, cache, vars_being_resolved)
            if isinstance(new_child, BoolLiteral):
                return new_child

            remaining_bound_vars = tuple(var for var in ast.bound_vars if var not in defs.definitions)
            if not remaining_bound_vars:
                return new_child

            return AST_Quantifier(referenced_vars=_referenced_vars_of(new_child), bound_vars=remaining_bound_vars,
                                  child=new_child)

        case _:
            raise NotImplementedError(f'Unhandled node while inlining bool var definitions: {ast=}')


def inline_bool_var_definitions(ast: ASTp_Node) -> ASTp_Node:
    """
    Inline "definitions" of Bool variables - unconditionally-true equivalences of the form `(= bool_var phi)`
    (or `(= phi bool_var)`) - by substituting every occurrence of bool_var with phi and dropping the now
    tautological defining equivalence.

    Example:
        (and (= b (or x y)) (or b z))   --->   (or x y z)

    Only equivalences reachable from the root through ANDs/quantifiers are inlined - see `_collect_bool_var_definitions`.
    A var defined more than once (with differing definitions), or whose definition refers to itself, is left untouched.
    """
    defs = Bool_Var_Definitions()
    _collect_bool_var_definitions(ast, defs)

    if not defs.definitions:
        return ast

    cache: Dict[Var, ASTp_Node] = {}
    return _inline_bool_var_definitions(ast, defs, cache, set())


@dataclass(frozen=True)
class FrozenLinAtom:
    coefs: Tuple[int, ...]
    vars: Tuple[Var, ...]
    predicate_sym: str
    rhs: int

    @staticmethod
    def from_relation(rel: Relation) -> FrozenLinAtom:
        return FrozenLinAtom(coefs=tuple(rel.coefs), vars=tuple(rel.vars),
                             predicate_sym=rel.predicate_symbol, rhs=rel.rhs)

@dataclass(frozen=True)
class FrozenCongruence:
    coefs: Tuple[int, ...]
    vars: Tuple[Var, ...]
    modulus: int
    rhs: int

    @staticmethod
    def from_congruence(congruence: Congruence) -> FrozenCongruence:
        return FrozenCongruence(coefs=tuple(congruence.coefs), vars=tuple(congruence.vars), modulus=congruence.modulus, rhs=congruence.rhs)


@dataclass
class Literal:
    positive: bool = field(hash=False)
    id: int = field(hash=True)


def _referenced_vars_of_children(children: Iterable[ASTp_Node]) -> Tuple[Var, ...]:
    refd_vars: Set[Var] = set()
    for child in children:
        refd_vars.update(_referenced_vars_of(child))
    return tuple(sorted(refd_vars))


def produce_dnf(and_literals: List[Literal], or_literals: List[Literal], literal_decoding_table: Dict[int, ASTp_Node]) -> ASTp_Node:
    produced_clauses: List[Tuple[Literal, ...]] = []
    for or_literal in or_literals:
        produced_clauses.append((or_literal, *and_literals))

    # Detect contradictions
    # @Performance: This implementation is simply terrible; definitely needs improvements
    simplified_clauses: List[List[Literal]] = []
    for clause in produced_clauses:
        simplified_clause: List[Literal] = []
        seen_literals: Dict[int, Literal] = {}

        is_clause_contradiction = False
        for literal in clause:
            if literal.id not in seen_literals:
                seen_literals[literal.id] = literal
                simplified_clause.append(literal)
            else:
                if seen_literals[literal.id].positive != literal.positive:
                    is_clause_contradiction = True
                    break
                else:
                    pass  # Do not include the same literal multiple times in the same clause

        if not is_clause_contradiction:
            simplified_clauses.append(simplified_clause)

    if not simplified_clauses:
        return BoolLiteral(value=False)


    def decode_literal(literal: Literal) -> ASTp_Node:
        atom = literal_decoding_table[literal.id]
        if literal.positive:
            return atom
        return AST_Negation(referenced_vars=_referenced_vars_of(atom), child=atom)

    def decode_clause(clause: Iterable[Literal]) -> ASTp_Node:
        decoded = tuple(decode_literal(literal) for literal in clause)
        return AST_Connective(referenced_vars=_referenced_vars_of_children(decoded), type=Connective_Type.AND, children=decoded)

    if len(simplified_clauses) == 1:  # Do not introduce an extra OR node
        clause = simplified_clauses[0]
        if len(clause) == 1:
            return decode_literal(clause[0])
        return decode_clause(clause)

    clauses = tuple(decode_clause(clause) for clause in simplified_clauses)
    return AST_Connective(referenced_vars=_referenced_vars_of_children(clauses), type=Connective_Type.OR, children=clauses)


def is_atom(ast: ASTp_Node) -> bool:
    atom_types = (BoolLiteral, Relation, Congruence, Var)
    return isinstance(ast, atom_types)


def is_literal(ast: ASTp_Node) -> bool:
    if is_atom(ast):
        return True

    return isinstance(ast, AST_Negation) and is_atom(ast.child)



LiteralIds = Tuple[int, ...]
LiteralIdDecodingTable = Dict[int, Literal]
FrozenAtom = Union[Var, BoolLiteral, FrozenLinAtom, FrozenCongruence]

def do_and_or_tree_lookahead_and_produce_dnf(ast: ASTp_Node) -> Optional[ASTp_Node]:
    if not (isinstance(ast, AST_Connective) and ast.type == Connective_Type.AND):
        return None

    children = ast.children
    and_literals_raw = [child for child in children if is_literal(child)]
    or_nodes = [child for child in children if isinstance(child, AST_Connective) and child.type == Connective_Type.OR]

    flattening_happened = len(or_nodes) == 1
    if not flattening_happened:
        return None

    if len(or_nodes) + len(and_literals_raw) != len(children):
        return None

    or_node = or_nodes[0]
    if not all(is_literal(or_child) for or_child in or_node.children):
        return None

    def freeze_atom(atom: ASTp_Node) -> FrozenAtom:
        if isinstance(atom, Relation):
            return FrozenLinAtom.from_relation(atom)
        elif isinstance(atom, Congruence):
            return FrozenCongruence.from_congruence(atom)
        else:
            assert isinstance(atom, Var) or isinstance(atom, BoolLiteral), atom
            return ('bool-literal', atom.value) if isinstance(atom, BoolLiteral) else atom

    # We have a valid AND-OR tree

    literal_decoding_table: Dict[int, ASTp_Node] = {}
    literal_table: Dict[FrozenAtom, int] = {}

    def make_atoms_into_literals(nodes: Iterable[ASTp_Node]) -> List[Literal]:
        literals: List[Literal] = []
        for node in nodes:
            child = node

            is_positive = True
            if isinstance(child, AST_Negation):
                child = child.child
                is_positive = False

            frozen_atom = freeze_atom(child)
            if frozen_atom in literal_table:
                literal_id = literal_table[frozen_atom]
            else:
                literal_id = len(literal_table)
                literal_table[frozen_atom] = literal_id
                literal_decoding_table[literal_id] = child
            literals.append(Literal(positive=is_positive, id=literal_id))
        return literals

    or_literals = make_atoms_into_literals(or_node.children)
    and_literals = make_atoms_into_literals(and_literals_raw)

    if not set(lit.id for lit in or_literals).issubset(lit.id for lit in and_literals):
        return None

    dnf = produce_dnf(and_literals, or_literals, literal_decoding_table)
    return dnf


def _convert_and_or_trees_to_dnf_if_talking_about_similar_atoms(ast: ASTp_Node) -> ASTp_Node:
    """
    Convert 2-deep AND-OR trees into DNF if they are talking about similar atoms.

    Conversion is performed if the subordinate tree is talking about a subset of parent atoms.
    """
    match ast:
        case Var() | BoolLiteral() | Relation() | Congruence():
            return ast

        case AST_Connective() if ast.type == Connective_Type.AND:
            # Are we dealing with an AND-OR tree?
            dnf = do_and_or_tree_lookahead_and_produce_dnf(ast)
            if dnf:
                return dnf

            children = tuple(_convert_and_or_trees_to_dnf_if_talking_about_similar_atoms(child) for child in ast.children)
            return ast.replace_children(children)

        case AST_Quantifier():
            return AST_Quantifier(referenced_vars=ast.referenced_vars, bound_vars=ast.bound_vars,
                                  child=_convert_and_or_trees_to_dnf_if_talking_about_similar_atoms(ast.child))

        case AST_Negation():
            return AST_Negation(referenced_vars=ast.referenced_vars,
                                child=_convert_and_or_trees_to_dnf_if_talking_about_similar_atoms(ast.child))

        case AST_Connective():  # OR, EQUIV - no lookahead applies, just descend
            children = tuple(_convert_and_or_trees_to_dnf_if_talking_about_similar_atoms(child) for child in ast.children)
            return ast.replace_children(children)

    raise NotImplementedError(f'Unhandled node while converting tree into DNF: {ast=}')


def convert_and_or_trees_to_dnf_if_talking_about_similar_atoms(ast: ASTp_Node) -> ASTp_Node:
    result = _convert_and_or_trees_to_dnf_if_talking_about_similar_atoms(ast)
    return result


def _collect_variables_present_in_formula(ast: ASTp_Node) -> Set[Var]:
    return set(_referenced_vars_of(ast))


def replace_congruence_component_with_term(congruence: Congruence, component: Tuple[Tuple[int, Var]], replace_term: Tuple[int, Var]) -> Congruence:
    component_vars = tuple(term[1] for term in component)

    new_terms: List[Tuple[int, Var]] = [term for term in congruence.linear_terms() if term[1] not in component_vars]
    new_terms.append(replace_term)
    new_terms = sorted(new_terms, key=lambda it: it[1])

    vars, coefs = [], []
    for coef, var in new_terms:
        vars.append(var)
        coefs.append(coef)

    return Congruence(vars=vars, coefs=coefs, rhs=congruence.rhs, modulus=congruence.modulus)



def _try_rewrite_congruence_on_unbund_vars(exists_and_tree: AST_Quantifier, var_table: Dict[Var, VarInfo]) -> Optional[AST_Quantifier]:
    bound_vars = exists_and_tree.bound_vars
    and_node = exists_and_tree.child
    assert isinstance(and_node, AST_Connective) and and_node.type == Connective_Type.AND
    leaves = and_node.children

    _used_vars = (_collect_variables_present_in_formula(leaf) for leaf in leaves if not isinstance(leaf, Congruence))
    used_vars = functools.reduce(set.union, _used_vars, set())
    bound_vars_used_only_in_congruences = set(bound_vars) - used_vars

    congruences, non_congruences = [], []
    for child in leaves:
        if isinstance(child, Congruence):
            congruences.append(child)
        else:
            non_congruences.append(child)

    if not bound_vars_used_only_in_congruences:
        return None

    new_congruences: List[Congruence] = []
    new_bound_vars: List[Var] = []
    var_to_replace_multiple_unbound_with = next(iter(bound_vars_used_only_in_congruences))

    LinTerm = Tuple[Tuple[int, Var], ...]
    unbound_components: Dict[LinTerm, Tuple[Var, List[int]]] = {}

    free_var_id = max(var_table).id + 1
    for congruence_idx, congruence in enumerate(congruences):
        unbound_vars: List[Var] = []
        unbound_coefs: List[int] = []
        for coef, var in zip(congruence.coefs, congruence.vars):
            if var in bound_vars_used_only_in_congruences:
                unbound_vars.append(var)
                unbound_coefs.append(coef)

        if not unbound_vars:
            new_congruences.append(congruence)
            continue

        component: Tuple[Tuple[int, Var], ...] = tuple(sorted(zip(unbound_coefs, unbound_vars), key=lambda it: it[0]))
        if component in unbound_components:
            unbound_components[component][1].append(congruence_idx)
        else:
            unbound_components[component] = (Var(free_var_id), [congruence_idx])
            free_var_id += 1

    for component, var_and_congruence_indices in unbound_components.items():
        var, congruence_indices = var_and_congruence_indices
        component_gcd = gcd(*(lin_term[0] for lin_term in component))

        if component_gcd == 1:
            # The term b.y can generate the entire ring (Z_mod, +, *). If there are multiple congruences,
            # then we need cannot drop them as they "communicate" via the term
            if len(congruence_indices) == 1:
                continue

            # There are multiple congruences with the same term, introduce a new single variable so they can
            # communicate
            replacement_term = (component_gcd, var)
            for congruence_idx in congruence_indices:
                congruence = congruences[congruence_idx]
                new_congruence = replace_congruence_component_with_term(congruence, component, replacement_term)
                new_congruences.append(new_congruence)

            new_bound_vars.append(var)
            continue

        # Modulus and GCD have some common divisor > 1, meaning that the rhs (-b.y + k) can generate only
        # some cyclic subset of Z_mod and we cannot further simplify the songruence
        if len(component) == 1:
            # The congruences are kept exactly as they were, so the component's original variable is
            # still referenced in them - it must remain part of the quantifier's binding list instead
            # of being dropped as if it had been eliminated.
            new_bound_vars.append(component[0][1])
            new_congruences.extend(congruences[idx] for idx in congruence_indices)
            continue

        coef = component_gcd
        replacement_term = (component_gcd, var)
        for congruence_idx in congruence_indices:
            congruence = congruences[congruence_idx]
            new_congruence = replace_congruence_component_with_term(congruence, component, replacement_term)
            new_congruences.append(new_congruence)

        new_bound_vars.append(var)

    # Variables that were part of some relations were not considered unbound and therefore they must be stil part of the quantifier
    new_binding_list = [var for var in bound_vars if var not in bound_vars_used_only_in_congruences] + new_bound_vars
    assert new_binding_list, exists_and_tree
    new_and_children = tuple([*non_congruences, *new_congruences])
    new_and_node = AST_Connective(referenced_vars=_referenced_vars_of_children(new_and_children), type=Connective_Type.AND, children=new_and_children)
    new_node = AST_Quantifier(referenced_vars=_referenced_vars_of(new_and_node), bound_vars=tuple(new_binding_list), child=new_and_node)

    for new_var in new_bound_vars:
        var_table[new_var] = VarInfo(name='congruence replacement', type=VariableType.INT)

    return new_node


def _simplify_congruences_on_unbounded_existential_vars(ast: ASTp_Node, var_table: Dict[Var, VarInfo]) -> ASTp_Node:
    match ast:
        case Var() | Relation() | Congruence() | BoolLiteral():
            return ast

        case AST_Quantifier():
            # Perform lookahead to check whether we have (exists Vars (and Atoms))
            if isinstance(ast.child, AST_Connective) and ast.child.type == Connective_Type.AND:
                new_ast = _try_rewrite_congruence_on_unbund_vars(ast, var_table)
                if new_ast:
                    return new_ast
            return AST_Quantifier(referenced_vars=ast.referenced_vars, bound_vars=ast.bound_vars,
                                  child=_simplify_congruences_on_unbounded_existential_vars(ast.child, var_table))

        case AST_Negation():
            return AST_Negation(referenced_vars=ast.referenced_vars,
                                child=_simplify_congruences_on_unbounded_existential_vars(ast.child, var_table))

        case AST_Connective():
            children = tuple(_simplify_congruences_on_unbounded_existential_vars(child, var_table) for child in ast.children)
            return ast.replace_children(children)

    raise NotImplementedError(f'Unhandled node while simplifying congruences on unbounded vars: {ast=}')


def simplify_congruences_on_unbounded_existential_vars(ast: ASTp_Node, var_table: Dict[Var, VarInfo]) -> ASTp_Node:
    ret = _simplify_congruences_on_unbounded_existential_vars(ast, var_table)
    return ret


def _collect_used_free_variables(ast: ASTp_Node, bound_vars: Set[Var]) -> Set[Var]:
    if isinstance(ast, Var):
        return {ast}
    if isinstance(ast, (Relation, Congruence)):
        return set(ast.vars).difference(bound_vars)
    if isinstance(ast, BoolLiteral):
        return set()

    if isinstance(ast, AST_Quantifier):
        new_bound_vars = bound_vars.union(ast.bound_vars)
        return _collect_used_free_variables(ast.child, new_bound_vars)

    if isinstance(ast, AST_Negation):
        return _collect_used_free_variables(ast.child, bound_vars)

    assert isinstance(ast, AST_Connective)
    return functools.reduce(set.union, (_collect_used_free_variables(child, bound_vars) for child in ast.children), set())


def _are_exists_and_trees_isomorphic(left: ASTp_Node, right: ASTp_Node, isomorphism: Dict[Var, Var]) -> bool:
    if type(left) != type(right):
        return False

    if isinstance(left, (Relation, Congruence)):
        assert isinstance(right, (Relation, Congruence))

        if len(left.vars) != len(right.vars):
            return False

        if sorted(left.coefs) != sorted(right.coefs) or left.rhs != right.rhs:
            return False
        if isinstance(left, Relation) and left.predicate_symbol != right.predicate_symbol:
            return False
        if isinstance(left, Congruence) and left.modulus != right.modulus:
            return False

        left_vars_to_coefs: Dict[Var, int] = {var:coef for coef, var in left.linear_terms()}
        right_vars_to_coefs: Dict[Var, int] = {var:coef for coef, var in right.linear_terms()}

        for left_var in left.vars:
            left_coef = left_vars_to_coefs[left_var]
            right_var = isomorphism.get(left_var, left_var)
            if right_var not in right_vars_to_coefs:
                # `left_var` maps to a variable that does not occur (at this position) on the
                # right side at all - not an isomorphism, not a crash.
                return False
            right_coef = right_vars_to_coefs[right_var]

            if left_coef != right_coef:
                return False
        return True

    if isinstance(left, BoolLiteral):
        assert isinstance(right, BoolLiteral)
        return left.value == right.value

    if isinstance(left, AST_Negation):
        assert isinstance(right, AST_Negation)
        return _are_exists_and_trees_isomorphic(left.child, right.child, isomorphism)

    if isinstance(left, AST_Quantifier):
        assert isinstance(right, AST_Quantifier)
        if len(left.bound_vars) != len(right.bound_vars):
            return False

        # @Incomplete: Extend the isomorphism in a naive fashion
        isomorphism = dict(isomorphism)
        for left_var, right_var in zip(left.bound_vars, right.bound_vars):
            isomorphism[left_var] = right_var

        return _are_exists_and_trees_isomorphic(left.child, right.child, isomorphism)

    if isinstance(left, AST_Connective):
        assert isinstance(right, AST_Connective)
        if left.type != right.type or len(left.children) != len(right.children):
            return False

        return all(
            _are_exists_and_trees_isomorphic(left_child, right_child, isomorphism)
            for left_child, right_child in zip(left.children, right.children)
        )

    logger.warning('Unhandled branch in isomorphism checking, assumimg that the trees are not isomorphic')
    return False


def are_exists_and_trees_isomorphic(left: ASTp_Node, right: ASTp_Node, free_vars: Iterable[Var]) -> bool:
    isomorphism = {free_var: free_var for free_var in free_vars}
    are_isomorphic = _are_exists_and_trees_isomorphic(left, right, isomorphism)
    return are_isomorphic


def _check_if_children_are_conflicting(children: List[ASTp_Node], free_vars: Tuple[Var, ...]) -> bool:
    positive, negative = [], []
    for child in children:
        if isinstance(child, AST_Negation):
            negative.append(child)
        else:
            positive.append(child)

    # @Incomplete: There could be other clauses that might nothing to do with the conflict
    if len(positive) != 1 or len(negative) != 1:
        return False

    neg_node = negative[0].child  # Strip the leading negation
    return are_exists_and_trees_isomorphic(positive[0], neg_node, free_vars)


def _detect_conflics_on_isomorphic_fragments(ast: ASTp_Node) -> ASTp_Node:
    """ Detects conflicting conjunctive clauses that conflict because of different renaming of bound vars. """
    match ast:
        case Var() | Relation() | Congruence() | BoolLiteral():
            return ast

        case AST_Quantifier():
            return AST_Quantifier(referenced_vars=ast.referenced_vars, bound_vars=ast.bound_vars,
                                  child=_detect_conflics_on_isomorphic_fragments(ast.child))

        case AST_Negation():
            return AST_Negation(referenced_vars=ast.referenced_vars, child=_detect_conflics_on_isomorphic_fragments(ast.child))

        case AST_Connective() if ast.type == Connective_Type.AND:
            rewritten_children = tuple(_detect_conflics_on_isomorphic_fragments(child) for child in ast.children)

            children: List[ASTp_Node] = [child for child in rewritten_children if isinstance(child, (AST_Connective, AST_Negation, AST_Quantifier))]
            free_vars_to_children: Dict[Tuple[Var, ...], List[ASTp_Node]] = defaultdict(list)
            for child in children:
                free_vars = tuple(sorted(_collect_used_free_variables(child, set())))
                free_vars_to_children[free_vars].append(child)

            for free_vars, children_with_same_free_vars in free_vars_to_children.items():
                # @Incomplete: There could be other clauses that might nothing to do with the conflict, for now we focus on (and A (not A))
                if len(children_with_same_free_vars) > 2:
                    continue

                if _check_if_children_are_conflicting(children_with_same_free_vars, free_vars):
                    return BoolLiteral(value=False)

            # No clauses were found conflicting
            return ast.replace_children(rewritten_children)

        case AST_Connective():
            return ast.replace_children(tuple(_detect_conflics_on_isomorphic_fragments(child) for child in ast.children))

    raise NotImplementedError(f'Unhandled node while detecting isomorphic conflicts: {ast=}')


def detect_conflics_on_isomorphic_fragments(ast: ASTp_Node) -> ASTp_Node:
    """ Detects conflicting conjunctive clauses that conflict because of different renaming of bound vars. """
    return _detect_conflics_on_isomorphic_fragments(ast)



@dataclass
class Parent_Context_Var_Values:
    """ Keeps track of values asserted in somewhere parent nodes. """
    seen_vars: Set[Var] = field(default_factory=set)
    asserted_var_values: List[Dict[Var, Value_Interval]] = field(default_factory=lambda: [defaultdict(Value_Interval)])

    def enter_context(self):
        new_ctx = {}
        self.asserted_var_values.append(new_ctx)

    def enter_blocking_context(self):
        new_ctx = {var: Value_Interval() for var in self.seen_vars}
        self.asserted_var_values.append(new_ctx)

    def lookup_asserted_values(self, var: Var) -> Value_Interval:
        for ctx in reversed(self.asserted_var_values):
            if var in ctx:
                return ctx[var]
        return Value_Interval()  # [-Inf,Inf]

    def exit_context(self):
        self.asserted_var_values.pop(-1)

    def assert_new_var_value(self, var: Var, new_interval: Value_Interval):
        self.seen_vars.add(var)

        active_ctx = self.asserted_var_values[-1]
        active_ctx[var] = new_interval

    def get_known_variable_domains(self) -> Dict[Var, Value_Interval]:
        domains = {}

        for context in reversed(self.asserted_var_values):
            domains.update(context)
            if len(domains) == len(self.seen_vars):
                return domains

        return domains


def _insert_all_asserting_bounds_into_current_context(and_connective: AST_Connective, contexter: Parent_Context_Var_Values):
    children = and_connective.children
    bounds = (child for child in children if isinstance(child, Relation) and len(child.vars) == 1)
    for bound in bounds:
        var, coef = bound.vars[0], bound.coefs[0]
        rhs = bound.rhs

        val_interval = contexter.lookup_asserted_values(var)

        if bound.predicate_symbol == '=':
            if (rhs % coef) != 0:
                return BoolLiteral(False)  # e.g. x >= 3, and we are in a child: (3x = 5 AND <Subformula>)
            implied_val = rhs // coef

            upper = val_interval.upper_limit if val_interval.upper_limit is not None else implied_val + 1
            lower = val_interval.lower_limit if val_interval.lower_limit is not None else implied_val - 1

            if implied_val < lower or implied_val > upper:
                return BoolLiteral(False)  # e.g. x >= 3, and we are in a child: (x = 0 AND <Subformula>)

            new_interval = Value_Interval(lower_limit=implied_val, upper_limit=implied_val)
            contexter.assert_new_var_value(var, new_interval)
            continue

        if coef < 0:  # Lower limit
            implied_val = -(-rhs // coef)  # ceil(rhs / coef), exact for integers of any size
            old_lower = val_interval.lower_limit if val_interval.lower_limit is not None else implied_val - 1
            new_lower = max(implied_val, old_lower)
            contexter.assert_new_var_value(var, Value_Interval(new_lower, val_interval.upper_limit))
        else:  # Upper limit
            implied_val = rhs // coef  # floor(rhs / coef)
            old_upper = val_interval.upper_limit if val_interval.upper_limit is not None else implied_val + 1
            new_upper = min(implied_val, old_upper)
            contexter.assert_new_var_value(var, Value_Interval(val_interval.lower_limit, new_upper))


def _prune_in_connective(connective: AST_Connective, contexter: Parent_Context_Var_Values) -> ASTp_Node:
    match connective.type:
        case Connective_Type.AND:
            contexter.enter_context()

            children = connective.children
            # The single-variable relations below are dropped and re-emitted from the context, so a
            # relation the context could not absorb - one contradicting it, e.g. `7x = 1` or `x = 0`
            # under `x >= 3` - must make the whole conjunction False rather than silently vanish.
            if _insert_all_asserting_bounds_into_current_context(connective, contexter) == BoolLiteral(False):
                contexter.exit_context()
                return BoolLiteral(False)

            new_bounds = []
            for var, var_values in contexter.asserted_var_values[-1].items():
                is_single_value_implied = var_values.lower_limit == var_values.upper_limit
                if var_values.lower_limit is not None and is_single_value_implied:
                    new_bounds.append(Relation(vars=[var], coefs=[1], rhs=var_values.lower_limit, predicate_symbol='='))
                    continue

                if var_values.lower_limit is not None:
                    new_bounds.append(Relation(vars=[var], coefs=[-1], rhs=-var_values.lower_limit, predicate_symbol='<='))

                if var_values.upper_limit is not None:
                    new_bounds.append(Relation(vars=[var], coefs=[1], rhs=var_values.upper_limit, predicate_symbol='<='))

            def is_bound(node: ASTp_Node):
                return isinstance(node, Relation) and len(node.vars) == 1

            _new_rich_children = (_prune_conjunctions_false_due_to_parent_context(child, contexter) for child in children if not is_bound(child))
            new_rich_children = tuple((child for child in _new_rich_children if child != BoolLiteral(True)))


            contexter.exit_context()

            if any(child == BoolLiteral(False) for child in new_rich_children):
                return BoolLiteral(False)

            new_subtree = (*new_bounds, *new_rich_children)
            if len(new_subtree) == 0:
                return BoolLiteral(True)
            if len(new_subtree) == 1:
                return new_subtree[0]

            new_node = AST_Connective(referenced_vars=connective.referenced_vars,
                                      type=Connective_Type.AND,
                                      children=new_subtree,
                                      variable_bounds=contexter.get_known_variable_domains())

            return new_node

        case Connective_Type.OR:
            _new_children = (_prune_conjunctions_false_due_to_parent_context(child, contexter) for child in connective.children)
            new_children = tuple(child for child in _new_children if child != BoolLiteral(False))

            if any(child == BoolLiteral(True) for child in new_children):
                return BoolLiteral(True)

            if len(new_children) == 0:
                return BoolLiteral(False)
            if len(new_children) == 1:
                return new_children[0]

            new_node = AST_Connective(referenced_vars=connective.referenced_vars, type=Connective_Type.OR, children=new_children)
            return new_node
        case Connective_Type.EQUIV:
            new_children = tuple(_prune_conjunctions_false_due_to_parent_context(child, contexter) for child in connective.children)
            return AST_Connective(referenced_vars=connective.referenced_vars, type=Connective_Type.EQUIV, children=new_children)
        case _:
            raise NotImplementedError(f'Connective not handled when doing interval analysis: {connective=}')


def three_value_logic_mult(value: int | None, scalar: int) -> int | None:
    return value * scalar if value is not None else None


def three_value_add(value: int | None, other_val: int | None) -> int | None:
    if value is None or other_val is None:
        return None
    return value + other_val


def compute_lin_term_expr_bound(rel: Relation, contexter: Parent_Context_Var_Values) -> Value_Interval:
    var_coefs_iterator = zip(rel.vars, rel.coefs)
    var, coef = next(var_coefs_iterator)

    lin_term_bounds = contexter.lookup_asserted_values(var).copy()
    lin_term_bounds.lower_limit = three_value_logic_mult(lin_term_bounds.lower_limit, coef)
    lin_term_bounds.upper_limit = three_value_logic_mult(lin_term_bounds.upper_limit, coef)
    if coef < 0:
        lin_term_bounds.lower_limit, lin_term_bounds.upper_limit = lin_term_bounds.upper_limit, lin_term_bounds.lower_limit

    for var, coef in var_coefs_iterator:
        var_bounds = contexter.lookup_asserted_values(var)
        lower_limit = three_value_logic_mult(var_bounds.lower_limit, coef)
        upper_limit = three_value_logic_mult(var_bounds.upper_limit, coef)
        if coef < 0:
            lower_limit, upper_limit = upper_limit, lower_limit

        lin_term_bounds.lower_limit = three_value_add(lin_term_bounds.lower_limit, lower_limit)
        lin_term_bounds.upper_limit = three_value_add(lin_term_bounds.upper_limit, upper_limit)

    return lin_term_bounds

def rewrite_using_bounds_on_lhs_lin_term(relation: Relation, contexter: Parent_Context_Var_Values) -> ASTp_Node | None:
    """
    Rewrite given relation by computing overapproximation of LHS values and checking its feasability.

    Enabled if solver_config.optimizations.rewrite_by_overapprox_relation_rhs is True.
    """
    if not solver_config.optimizations.rewrite_existential_equations_via_gcd:
        return None

    if relation.predicate_symbol == '<=':
        lhs_expr_bound = compute_lin_term_expr_bound(relation, contexter)
        if lhs_expr_bound.lower_limit is not None and lhs_expr_bound.lower_limit > relation.rhs:
            return BoolLiteral(False)
        elif lhs_expr_bound.upper_limit is not None and lhs_expr_bound.upper_limit <= relation.rhs:
            return BoolLiteral(True)
    elif relation.predicate_symbol == '=':
        lhs_expr_bound = compute_lin_term_expr_bound(relation, contexter)
        higher_than_lower_lim = relation.rhs >= lhs_expr_bound.lower_limit if lhs_expr_bound.lower_limit is not None else True
        lower_than_upper_lim = relation.rhs <= lhs_expr_bound.upper_limit if lhs_expr_bound.upper_limit is not None else True
        can_be_satisfied = higher_than_lower_lim and lower_than_upper_lim
        if not can_be_satisfied:
            return BoolLiteral(False)
    return None


def _prune_conjunctions_false_due_to_parent_context(node: ASTp_Node, contexter: Parent_Context_Var_Values) -> ASTp_Node:
    if isinstance(node, Relation):
        relation: Relation = node

        if not relation.vars:
            # A fully constant atom (e.g. `0 <= 5`) - nothing to reason about against parent
            # context, but the code below indexes vars[0]/coefs[0] and would crash on it.
            return BoolLiteral(relation.is_always_satisfied())

        if len(relation.vars) > 1:
            rel_rewritten_using_bounds = rewrite_using_bounds_on_lhs_lin_term(relation, contexter)
            if rel_rewritten_using_bounds is not None:
                return rel_rewritten_using_bounds
            return node

        var, coef = relation.vars[0], relation.coefs[0]
        rhs = relation.rhs

        if relation.predicate_symbol == '<=':

            ctx_vals = contexter.lookup_asserted_values(var)

            if coef < 0:
                implied_val = -(-rhs // coef)  # ceil(rhs / coef), exact for integers of any size
                # Look whether the current bound requires var value to be higher then possible due to parent's constraints
                parents_upper_limit = ctx_vals.upper_limit if ctx_vals.upper_limit is not None else implied_val + 1
                if implied_val > parents_upper_limit:  # Parent asserts that x must be <= than 5, child says x must be >= 6
                    return BoolLiteral(False)

                # Look whether we are strengthening the lower bound or not
                ctx_lower_val = ctx_vals.lower_limit
                if not ctx_lower_val:
                    return node

                if ctx_lower_val > implied_val:  # The relation can be strenghtened
                    rhs = -ctx_lower_val   # Because coef is negative -x <= k  <-> x >= -k
                    return Relation(vars=relation.vars, coefs=[-1], rhs=rhs, predicate_symbol='<=')
            else:  # coef > 0
                implied_val = rhs // coef  # floor(rhs / coef)
                parents_lower_limit = ctx_vals.lower_limit if ctx_vals.lower_limit is not None else implied_val - 1
                if implied_val < parents_lower_limit:  # Parent asserts that x must be >= 0, child says x must be <= -1
                    return BoolLiteral(False)

                ctx_upper_val = ctx_vals.upper_limit
                if not ctx_upper_val:
                    return node

                if ctx_upper_val < implied_val:  # The relation can be strenghtened
                    return Relation(vars=relation.vars, coefs=[1], rhs=ctx_upper_val, predicate_symbol='<=')
            return node

        # relation is an equation
        if (relation.rhs % coef) != 0:  # -2x = 5
            return BoolLiteral(False)

        implied_val = relation.rhs // coef  # x = +/- implied_value
        val_interval = contexter.lookup_asserted_values(var)

        upper = val_interval.upper_limit if val_interval.upper_limit is not None else implied_val + 1
        lower = val_interval.lower_limit if val_interval.lower_limit is not None else implied_val - 1

        if implied_val < lower or implied_val > upper:
            return BoolLiteral(False)

        return Relation(vars=[var], coefs=[1], rhs=implied_val, predicate_symbol='=')

    if isinstance(node, (Congruence, Var, BoolLiteral)):  # Congruences, BoolLiterals etc
        return node

    match node:
        case AST_Connective():
            return _prune_in_connective(node, contexter)

        case AST_Negation():
            child = node.child
            if isinstance(child, Relation) and child.predicate_symbol == '=' and len(child.vars) == 1:
                # Check if what the negated equation implies is already implied from parent context.
                # Only applies to a single-variable equation - the code below indexes vars[0]/coefs[0]
                # and reasons about one variable's asserted interval, so a 0-variable (constant) or
                # multi-variable equation must fall through to the generic handling below instead.
                eq = child
                var, coef, rhs = eq.vars[0], eq.coefs[0], eq.rhs
                if (rhs % coef) != 0:
                    return BoolLiteral(True)
                implied_val = rhs // coef

                val_interval = contexter.lookup_asserted_values(var)
                upper = val_interval.upper_limit if val_interval.upper_limit is not None else implied_val + 1
                lower = val_interval.lower_limit if val_interval.lower_limit is not None else implied_val - 1

                # If the implied_value is not included in the interval, then we can just ignore it
                if implied_val < lower or implied_val > upper:
                    return BoolLiteral(True)

            # Once we've passed through a negation we forget everything about parent context.
            # alternatively, we would need a ritcher interval domain to precisely handle nagations.
            # contexter.enter_blocking_context()
            new_child = _prune_conjunctions_false_due_to_parent_context(child, contexter)
            new_node = AST_Negation(referenced_vars=node.referenced_vars, child=new_child)
            # contexter.exit_context()
            return new_node

        case AST_Quantifier():
            child = _prune_conjunctions_false_due_to_parent_context(node.child, contexter)
            return AST_Quantifier(referenced_vars=node.referenced_vars, bound_vars=node.bound_vars, child=child)

        case _:
            raise NotImplementedError(f'ASTp node not handled when doing interval analysis: {node=}')


def prune_conjunctions_false_due_to_parent_context(root: ASTp_Node) -> ASTp_Node:
    """
    Remove conjunctions that are false due to them assessing variable values that are falsified in partent contexts.

    For example:
        (and (>= x 0) (or (and (= x 3) (= y 2)) <Subformula>)) would remove (and (= x 3) (= y  2))
    """
    contexter = Parent_Context_Var_Values()
    result = _prune_conjunctions_false_due_to_parent_context(root, contexter)
    return result


@dataclass
class Var_Monotonicity:
    increasing: bool = False
    decreasing: bool = False
    congruences: List[Tuple[int, Congruence]] = field(default_factory=list)
    limits: Value_Interval = field(default_factory=Value_Interval)


def _set_limit_on_interestring_var_if_bound(relation: Relation, var_info: Dict[Var, Var_Monotonicity], is_positive: bool) -> bool:
    """
    Set the hard limit information for a variable if that is the semantics of the given relation.

    Returns:
        True if a variable (hard) bound was set.
    """
    if relation.is_hard_bound():
        var, coef = relation.vars[0], relation.coefs[0]

        if var not in var_info or coef == 0:
            return True  # The relation is a hard bound (True), but it carries no information about an interesting variable

        # Exact integer division: float division rounds incorrectly once |rhs| exceeds 2**53.
        bounds = var_info[var]
        if coef < 0:
            bound_val = -(-relation.rhs // coef)  # ceil(rhs/coef): -3x <= 1 ---> x >= (-1/3) ---> x is in [0, ...]
            bounds.limits.try_strengthen_lower(bound_val)
        else:
            bound_val = relation.rhs // coef      # floor(rhs/coef): 3x <= 1 ---> x <= (1/3) ---> x is in [..., 0]
            bounds.limits.try_strengthen_upper(bound_val)
        return True

    elif relation.specifies_a_single_value_for_var():
        if not is_positive:
            var = relation.vars[0]
            bounds = var_info[var]
            bounds.increasing = True
            bounds.decreasing = True
            return True

        var, coef = relation.vars[0], relation.coefs[0]
        if var not in var_info or coef == 0:
            return True

        # c*x = k holds for x in [ceil(k/c), floor(k/c)]: a single value when c divides k, and an empty
        # interval otherwise (e.g. 7x = 1), which `_do_bounds_imply_conflict` reports as a conflict.
        bounds = var_info[var]
        bounds.limits.try_strengthen_lower(-(-relation.rhs // coef))
        bounds.limits.try_strengthen_upper(relation.rhs // coef)
        return True
    return False


@dataclass
class Monotonicity_Info:
    are_bounds_unsure: bool = False
    seen_vars: Dict[Var, Var_Monotonicity] = field(default_factory=lambda: defaultdict(Var_Monotonicity))
    congruence_counter: int = 0

    def should_analyse_var(self, var: Var) -> bool:
        return var in self.seen_vars

    def get_next_congruence_id(self) -> int:
        congruence_id = self.congruence_counter
        self.congruence_counter += 1
        return congruence_id


def _determine_monotonicity_of_variables(tree: ASTp_Node, monotonicity_info: Monotonicity_Info, is_positive: bool) -> None:
    match tree:
        case Relation():
            if _set_limit_on_interestring_var_if_bound(tree, monotonicity_info.seen_vars, is_positive):
                return

            for coef, var in tree.linear_terms():
                if not monotonicity_info.should_analyse_var(var):
                    continue

                if tree.predicate_symbol == '=':
                    var_monotonicity = monotonicity_info.seen_vars[var]
                    var_monotonicity.increasing = True
                    var_monotonicity.decreasing = True
                    continue

                if coef < 0:
                    monotonicity_info.seen_vars[var].increasing = True
                else:
                    monotonicity_info.seen_vars[var].decreasing = True

        case Congruence():
            for var_idx, var in enumerate(tree.vars):
                if monotonicity_info.should_analyse_var(var):
                    congruence_idx = monotonicity_info.get_next_congruence_id()
                    monotonicity_info.seen_vars[var].congruences.append((congruence_idx, tree))

        case BoolLiteral() | Var():
            return

        case AST_Connective():
            # The monotonicity analysis is an underapproximation - although different OR branches might
            # imply different variable monotonicity, the result is the same as if traversing through AND
            for child in tree.children:
                _determine_monotonicity_of_variables(child, monotonicity_info, is_positive)

        case AST_Negation():
            # Only thing that we should be able to see at this point is (not <eq>) since all of the negations
            # have been pushed inwards. An equation automatically implies that we do not know the monotonicity
            # of any variable, and therefore, it should be OK to just recurse down.
            _determine_monotonicity_of_variables(tree.child, monotonicity_info, is_positive=(not is_positive))

        case AST_Quantifier():
            for var in tree.bound_vars:
                assert var not in monotonicity_info.seen_vars or monotonicity_info.seen_vars[var] == Var_Monotonicity()
                monotonicity_info.seen_vars[var] = Var_Monotonicity()

            _determine_monotonicity_of_variables(tree.child, monotonicity_info, is_positive=is_positive)

        case _:
            raise ValueError(f'Node not handled when determining monotonicity of variable: {tree=}')


def _substitute_var_with_value(root: ASTp_Node, var: Var, value: Optional[int], contexter: Parent_Context_Var_Values) -> ASTp_Node:
    """ Substitute a *free* variable with a given value (None=inf). """
    match root:
        case Relation() | Congruence():
            if var not in root.vars:
                # Just make a note about the var values asserted here, as other places where the substitution
                # was successful might induce a conflict.
                if isinstance(root, Relation) and len(root.vars) == 1:
                    other_var = root.vars[0]
                    value_interval = contexter.lookup_asserted_values(other_var)
                    value_interval.apply_assertion(root)
                    contexter.assert_new_var_value(other_var, value_interval)
                return root

            if value is None:
                return BoolLiteral(True)

            new_coefs, new_vars = [], []
            var_coef = 1
            for other_coef, other_var in root.linear_terms():
                if other_var == var:
                    var_coef = other_coef
                    continue
                new_coefs.append(other_coef)
                new_vars.append(other_var)

            new_rhs = root.rhs - var_coef*value

            if not new_vars:
                if isinstance(root, Relation):
                    ret = BoolLiteral(new_rhs == 0 if root.predicate_symbol == '=' else new_rhs >= 0)
                    return ret
                else:  # root is a Congruence
                    ret = BoolLiteral(True) if (new_rhs % root.modulus) == 0 else BoolLiteral(False)
                    return ret

            if isinstance(root, Congruence):
                new_congruence = Congruence(vars=new_vars, coefs=new_coefs, rhs=(new_rhs % root.modulus), modulus=root.modulus)
                return new_congruence

            coefs_gcd = math.gcd(*new_coefs)
            if root.predicate_symbol == '=' and (new_rhs % coefs_gcd) != 0:
                # Unsat, e.g., 3x = 4 does not have a solution in integers
                return BoolLiteral(False)

            new_rhs = new_rhs // coefs_gcd  # floor(new_rhs / coefs_gcd), exact for integers of any size
            new_coefs = [coef // coefs_gcd for coef in new_coefs]
            relation = Relation(vars=new_vars, coefs=new_coefs, rhs=new_rhs, predicate_symbol=root.predicate_symbol)

            strengthened = False
            if relation.is_hard_bound():
                bound_type, affected_var, bound_val = get_hard_bound_semantics(relation)
                value_interval = contexter.lookup_asserted_values(affected_var)
                if bound_type == Bound_Type.LOWER:
                    value_interval.try_strengthen_lower(bound_val)
                else:
                    value_interval.try_strengthen_upper(bound_val)

            elif relation.specifies_a_single_value_for_var():
                affected_var = relation.vars[0]
                implied_val = relation.rhs // relation.coefs[0]  # We know that coefs divides rhs because otherwise we would already returned False
                value_interval = contexter.lookup_asserted_values(affected_var)
                value_interval.try_strengthen_lower(implied_val)
                value_interval.try_strengthen_upper(implied_val)

            else:
                return relation

            # We have strengthened the intervals, check whether we did not found any conflict after substitution
            if value_interval.implies_contradiction():
                return BoolLiteral(False)
            return relation

        case BoolLiteral() | Var():
            return root

        case AST_Connective():
            def subst_value_with_separate_context(node: ASTp_Node, var: Var, value: Optional[int], contexter: Parent_Context_Var_Values) -> ASTp_Node:
                contexter.enter_context()
                result = _substitute_var_with_value(node, var, value, contexter)
                contexter.exit_context()
                return result

            if root.type == Connective_Type.AND:
                # If we have an AND node then the subtrees can share asserted values (if a subtree asserts that x=5 then x=5 must hold in all other subtrees)
                contexter.enter_context()
                _subst_children = (_substitute_var_with_value(child, var, value, contexter) for child in root.children)
                subst_children = tuple(child for child in _subst_children if child is not None)
                contexter.exit_context()
            else:
                _subst_children = (subst_value_with_separate_context(child, var, value, contexter) for child in root.children)
                subst_children = tuple(child for child in _subst_children if child is not None)

            subst_children = _use_bool_laws_to_simplify_connective_plain(root.type, subst_children)
            if len(subst_children) == 1:
                return subst_children[0]

            return root.replace_children(subst_children)

        case AST_Quantifier():
            new_child = _substitute_var_with_value(root.child, var, value, contexter)
            if isinstance(new_child, BoolLiteral):
                return new_child
            new_bound_vars = root.bound_vars if var not in root.bound_vars else tuple(it for it in root.bound_vars if it != var)
            return AST_Quantifier(referenced_vars=root.referenced_vars, bound_vars=new_bound_vars, child=new_child)

        case AST_Negation():
            contexter.enter_blocking_context()

            new_child = _substitute_var_with_value(root.child, var, value, contexter)

            if new_child == BoolLiteral(True):
                return BoolLiteral(False)
            elif new_child == BoolLiteral(False):
                return BoolLiteral(True)
            elif isinstance(new_child, Relation) and new_child.predicate_symbol == '<=':
                return new_child.negate()

            contexter.exit_context()
            return AST_Negation(referenced_vars=root.referenced_vars, child=new_child)

        case _:
            raise ValueError(f'Invalid substitution. Trying substitute {var} := {value} into {type(root)}')


def _do_bounds_imply_conflict(var_info: Var_Monotonicity) -> bool:
    if var_info.limits.lower_limit is None or var_info.limits.upper_limit is None:
        return False

    return var_info.limits.upper_limit < var_info.limits.lower_limit


@dataclass
class Rewrite_Info:
    result: ASTp_Node
    rewrite_happend: bool = False
    should_continue: bool = True  # Contains meaningful value only when rewrite_happend=True
    quantifier_present: bool = True  # Contains meaningful value only when rewrite_happend=True


def _rewrite_exists_equations(exists_node: AST_Quantifier) -> Optional[Tuple[ASTp_Node, bool]]:
    if not isinstance(exists_node.child, Relation):
        return None

    bound_vars = exists_node.bound_vars
    rel = exists_node.child
    if rel.predicate_symbol == '=':
        bound_vars_coefs = []
        for coef, var in rel.linear_terms():
            if var in bound_vars:
                bound_vars_coefs.append(coef)
        gcd = math.gcd(*bound_vars_coefs)
        if not bound_vars_coefs:
            return rel, False
        if gcd == 1:
            return BoolLiteral(True), False
    else:
        if any(bound_var in rel.vars for bound_var in bound_vars):
            return BoolLiteral(True), False
        else: # Inequation that does not speak about the quantified variable.
            return exists_node.child, False
    return None


def _rewrite_surjective_transformations(exists_node: AST_Quantifier) -> Rewrite_Info:
    if not isinstance(exists_node.child, AST_Connective) or exists_node.child.type != Connective_Type.AND:
        return Rewrite_Info(result=exists_node, rewrite_happend=False)

    and_node: AST_Connective = exists_node.child

    if not all(isinstance(subtree, Relation) for subtree in and_node.children):
        return Rewrite_Info(result=exists_node, rewrite_happend=False)

    # E(x1) (x1 >= 0 /\ x1 - 5x2 \in [0, 4])    <-->  x2 >= 0    [IMPLEMENTED]
    # E(x2) (x2 >= 0 /\ x1 - 5x2 \in [K, K+4])  <-->  x1 >= K    [NOT IMPLEMENTED]
    # E(x1) (x1 >= 0 /\ x1  = 5x2)            <-->  True
    # E(x1) (x1 >= 0 /\ 5x1 = x2)             <-->  (x2 = 0 mod 5) /\ x2 >= 0
    Linear_Term = Tuple[int, Var]
    for bound_var in exists_node.bound_vars:

        bound_var_value = Value_Interval()

        dependencies: Dict[Var, List[int]] = defaultdict(list)

        is_surjection = False
        bound_var_has_other_constraints = False

        relations: Tuple[Relation,...] = and_node.children  # type: ignore
        for subtree_idx, subtree in enumerate(relations):
            assert isinstance(subtree, Relation)
            if not bound_var in subtree.vars:
                continue

            if len(subtree.vars) == 1 and not subtree.is_hard_bound():
                # e.g. (= q 0): neither a bound nor a dependency, the rewrite below would silently drop it
                bound_var_has_other_constraints = True
                break

            if subtree.is_hard_bound():
                bound_type, _, bound_val = get_hard_bound_semantics(subtree)
                if bound_type == Bound_Type.LOWER:
                    bound_var_value.try_strengthen_lower(bound_val)
                else:
                    bound_var_value.try_strengthen_upper(bound_val)
                continue

            for var in subtree.vars:
                if var == bound_var:
                    continue
                dependencies[var].append(subtree_idx)

        is_fin = (bound_var_value.upper_limit is not None) and (bound_var_value.lower_limit is not None)
        if is_fin or bound_var_has_other_constraints:
            continue

        if len(dependencies) > 1:
            # @Incomplete: There are multiple variables dependent on this one...
            # but I am not sure whether there can be any simplification done.
            # maybe we could do something better than nothing.
            continue

        rels_to_replace: List[Tuple[List[int], List[ASTp_Node]]] = []
        for dependent_var, relation_indices in dependencies.items():
            if not len(relation_indices) == 2:
                continue

            rel1, rel2 = relations[relation_indices[0]], relations[relation_indices[1]]

            if rel1.predicate_symbol != '<=' or rel2.predicate_symbol != '<=':
                continue

            rel1_terms = tuple(rel1.linear_terms())
            rel2_terms = tuple(rel2.linear_terms())
            rel2_terms_negated = tuple((-it[0], it[1]) for it in rel2_terms)

            are_terms_complementary = rel1_terms == rel2_terms_negated
            if not are_terms_complementary or len(rel1_terms) > 2:
                continue

            bound_var_idx = rel1.vars.index(bound_var)
            dep_var_idx = 1 - bound_var_idx
            pos, neg = rel1, rel2

            if abs(pos.coefs[bound_var_idx]) == 1:  #  E(x1) (x1 >= 0 /\ x1 - 5x2 \in [0, 4])    <-->  x2 >= 0
                if pos.coefs[bound_var_idx] == -1:
                    pos, neg = neg, pos

                # pos :=  1x + k*<neg> <= Z1,
                # neg := -1x - k*<neg> <= Z2,
                value_interval = Value_Interval(lower_limit=neg.rhs, upper_limit=pos.rhs)
                if value_interval.lower_limit != 0:
                    continue

                other_var_coef = pos.coefs[dep_var_idx]

                if value_interval.upper_limit != (-other_var_coef) - 1:
                    continue

                new_bounds: List[ASTp_Node] = list(bound_var_value.synthetize_atoms(rel1.vars[dep_var_idx]))
                rels_to_replace.append((relation_indices, new_bounds))

            elif abs(pos.coefs[dep_var_idx]) == 1:  #  E(x2) (x2 >= 0 /\ x1 - 5x2 \in [K, K+4])  <-->  x1 >= K
                if pos.coefs[dep_var_idx] == -1:  # Pos looks like 5x2 - x1, swap so pos would be x1 - 5x2
                    pos, neg = neg, pos

                # pos :=  1x - 5x2 <= Z1,
                # neg := -1x - 5x2 <= Z2    <=>   1x + 5x2 >= -Z2
                value_interval_width = pos.rhs + neg.rhs + 1# -(-Z2); +1 because range is inclusive, i.e., [a,a] contains 1 number
                bound_var_coef = -pos.coefs[bound_var_idx]

                if value_interval_width != bound_var_coef:
                    continue

                if bound_var_value.lower_limit is None and bound_var_value.upper_limit is None:
                    #  E(x2) (x1 - 5x2 \in [K, K+4]) - says nothing about the value of free variable
                    rels_to_replace.append((relation_indices, []))
                    continue

                if bound_var_value.lower_limit != 0 or bound_var_value.upper_limit is not None:
                    continue

                dep_var = pos.vars[dep_var_idx]
                implied_bound = Relation(vars=[dep_var], coefs=[-1], rhs=neg.rhs, predicate_symbol='<=')

                rels_to_replace.append((relation_indices, [implied_bound]))

        added_subformulae: List[ASTp_Node] = []
        removed_subformulae_indices: List[int] = []
        for thrown_out_atom_indices, new_atoms in rels_to_replace:
            removed_subformulae_indices.extend(thrown_out_atom_indices)
            added_subformulae.extend(new_atoms)

        kept_relations: Tuple[ASTp_Node,...] = tuple(subtree for subtree_idx, subtree in enumerate(relations) if subtree_idx not in removed_subformulae_indices)
        new_node_subtrees = kept_relations + tuple(added_subformulae)
        if not new_node_subtrees:
            new_node_subtrees = (BoolLiteral(True),)

        new_connective = AST_Connective(referenced_vars=and_node.referenced_vars, type=and_node.type, children=new_node_subtrees)

        result = AST_Quantifier(referenced_vars=exists_node.referenced_vars,
                                bound_vars=exists_node.bound_vars,
                                child=new_connective if len(new_connective.children) > 1 else new_connective.children[0])

        return Rewrite_Info(result=result, rewrite_happend=True, should_continue=True, quantifier_present=True)

    return Rewrite_Info(result=exists_node, rewrite_happend=False, should_continue=True, quantifier_present=True)


@dataclass
class Exists_Optimization_Result:
    node: ASTp_Node
    contains_quantifier: bool
    contains_rewritable_congruence: bool = False
    vars_to_rewrite_congruences_with: List[Var] = field(default_factory=list)


def _optimize_congruences_on_unbound_vars(root: ASTp_Node, opt_result: Exists_Optimization_Result) -> ASTp_Node:
    def filter_our_referenced_vars(referenced_vars: Tuple[Var, ...]) -> Tuple[Var, ...]:
        return tuple(var for var in referenced_vars if var not in opt_result.vars_to_rewrite_congruences_with)

    match root:
        case Relation():
            if any(var in root.vars for var in opt_result.vars_to_rewrite_congruences_with):
                return BoolLiteral(True)
            return root
        case Congruence():
            usable_terms: List[LinTerm] = [LinTerm(coef=term[0], var=term[1]) for term in root.linear_terms() if term[1] in opt_result.vars_to_rewrite_congruences_with]
            terms_gcd = math.gcd(*(term.coef for term in usable_terms))
            new_modulus = math.gcd(root.modulus, terms_gcd)

            new_terms = [term for term in root.linear_terms() if term[1] not in opt_result.vars_to_rewrite_congruences_with]
            coefs = [term[0] for term in new_terms]
            vars  = [term[1] for term in new_terms]

            if not vars:
                return BoolLiteral(root.rhs % new_modulus == 0)

            return Congruence(vars=vars, coefs=coefs, modulus=new_modulus, rhs=(root.rhs % new_modulus))
        case Var():
            return root
        case AST_Connective():
            rewritten_children = (_optimize_congruences_on_unbound_vars(child, opt_result) for child in root.children)
            referenced_vars = filter_our_referenced_vars(root.referenced_vars)
            return AST_Connective(referenced_vars=referenced_vars, type=Connective_Type.AND, children=tuple(rewritten_children))
        case AST_Quantifier():
            optimized_child = _optimize_congruences_on_unbound_vars(root.child, opt_result)
            bound_vars = tuple(var for var in root.bound_vars if var not in opt_result.vars_to_rewrite_congruences_with)
            if not bound_vars:
                return optimized_child
            if isinstance(optimized_child, BoolLiteral):
                return optimized_child
            referenced_vars = filter_our_referenced_vars(root.referenced_vars)
            return AST_Quantifier(referenced_vars=referenced_vars, bound_vars=bound_vars, child=optimized_child)
        case AST_Negation():
            optimized_child = _optimize_congruences_on_unbound_vars(root.child, opt_result)
            referenced_vars = filter_our_referenced_vars(root.referenced_vars)
            return AST_Negation(referenced_vars=referenced_vars, child=optimized_child)
        case _:
            raise ValueError('Unhandled node while optimizing congruences on unbound variables.')


def optimize_congruences_on_unbound_vars(root: ASTp_Node, opt_result: Exists_Optimization_Result) -> Exists_Optimization_Result:
    optimized_tree = _optimize_congruences_on_unbound_vars(root, opt_result)
    contains_quantifier = isinstance(root, AST_Quantifier)
    return Exists_Optimization_Result(node=optimized_tree, contains_quantifier=contains_quantifier)


def _optimize_exists_tree(exists_node: AST_Quantifier) -> Exists_Optimization_Result:
    """
    Optimize the structure of exists (X) where X is quantifier free.

    Returns:
        - A possibly optimized X
        - True if any quantifier lingers (is still present)
    """

    # Apply specific rewrite rules
    logger.debug('Optimizing exists tree: %s', exists_node)
    if (rewrite_info := _rewrite_exists_equations(exists_node)):
        return Exists_Optimization_Result(node=rewrite_info[0], contains_quantifier=rewrite_info[1])

    rewrite_info = _rewrite_surjective_transformations(exists_node)
    if rewrite_info.rewrite_happend:
        if not rewrite_info.should_continue:
            return Exists_Optimization_Result(rewrite_info.result, contains_quantifier=rewrite_info.quantifier_present)

        assert rewrite_info.quantifier_present
        assert isinstance(rewrite_info.result, AST_Quantifier)

        exists_node = rewrite_info.result

    monotonicity_info = Monotonicity_Info()
    _determine_monotonicity_of_variables(exists_node, monotonicity_info, is_positive=True)

    vars_to_instantiate: List[Tuple[Var, int | None]] = []
    contains_optimizable_congruences: bool = False
    vars_to_optimize_congruences_with: List[Var] = []
    for var, var_monotonicity in monotonicity_info.seen_vars.items():
        if _do_bounds_imply_conflict(var_monotonicity):
            return Exists_Optimization_Result(node=BoolLiteral(False), contains_quantifier=False)

        if var_monotonicity.limits.upper_limit == var_monotonicity.limits.lower_limit and var_monotonicity.limits.lower_limit is not None:
            logger.info(f'The variable {var} has a known value {var_monotonicity.limits.upper_limit}')
            # The variable has a known value so we can instantiate it regardless of its context
            vars_to_instantiate.append((var, var_monotonicity.limits.upper_limit))
            continue

        is_variable_in_other_atoms = var_monotonicity.increasing or var_monotonicity.decreasing
        is_direction_of_optimal_value_known = (var_monotonicity.increasing != var_monotonicity.decreasing)
        if not is_direction_of_optimal_value_known and is_variable_in_other_atoms:
            continue  # Some atoms would like the variable to be large, some would like it to be small...

        var_causes_nonlinearities = len(var_monotonicity.congruences) > 0
        if is_direction_of_optimal_value_known and not var_causes_nonlinearities:
            optimal_value = var_monotonicity.limits.upper_limit if var_monotonicity.increasing else var_monotonicity.limits.lower_limit
            vars_to_instantiate.append((var, optimal_value))
            continue

        # Assess whether the variable can be inf in a suitable direction - then we can deal with one Congruence
        var_has_limited_nonlinearity = len(var_monotonicity.congruences) == 1
        can_be_pos_inf = (not var_monotonicity.decreasing) and var_monotonicity.limits.upper_limit is None
        can_be_neg_inf = (not var_monotonicity.increasing) and var_monotonicity.limits.lower_limit is None
        can_be_inf = can_be_pos_inf or can_be_neg_inf

        if can_be_inf and var_has_limited_nonlinearity:
            congruence_idx, congruence = var_monotonicity.congruences[0]
            var_idx = congruence.vars.index(var)
            coef = (-congruence.coefs[var_idx] + congruence.modulus) % congruence.modulus  # Move x to the other side
            new_mod = gcd(coef, congruence.modulus)
            if gcd(coef, congruence.modulus) == 1:
                vars_to_instantiate.append((var, None))
            else:
                contains_optimizable_congruences = True
                vars_to_optimize_congruences_with.append(var)

        if not is_variable_in_other_atoms and len(var_monotonicity.congruences) == 0 and can_be_inf:  # Var has only limits of the type \exists x (x >= 10 AND x >= 20), so it can be instantiated with -infty
            vars_to_instantiate.append((var, None))

    optimized_tree_child = exists_node.child
    if vars_to_instantiate:
        for var, var_value in vars_to_instantiate:
            var_info   = monotonicity_info.seen_vars[var]
            logger.debug('Substituting %s=%s into the exists tree', var, var_value)
            fixed_tree = _substitute_var_with_value(optimized_tree_child, var, var_value, Parent_Context_Var_Values())
            logger.debug('Fixed tree: %s', fixed_tree)
            if not fixed_tree:
                return Exists_Optimization_Result(node=BoolLiteral(True), contains_quantifier=False)
            optimized_tree_child = fixed_tree

        quantifier_lingers = len(exists_node.bound_vars) - len(vars_to_instantiate) > 0

        instantiated_vars: Set[Var] = set(var for var, _ in vars_to_instantiate)
        remaining_quantified_vars: Tuple[Var, ...] = tuple(sorted(set(exists_node.bound_vars) - instantiated_vars))
        if remaining_quantified_vars:
            referenced_vars = tuple(set(exists_node.referenced_vars) - instantiated_vars)
            optimized_tree = AST_Quantifier(referenced_vars=referenced_vars, bound_vars=remaining_quantified_vars, child=optimized_tree_child)
        else:
            optimized_tree = optimized_tree_child  # All variables have been instantiated; remove the quantifier node

        logger.debug('Result: %s', optimized_tree)
        return Exists_Optimization_Result(node=optimized_tree,
                                          contains_quantifier=quantifier_lingers,
                                          contains_rewritable_congruence=contains_optimizable_congruences,
                                          vars_to_rewrite_congruences_with=vars_to_optimize_congruences_with)

    logger.debug('Did not perform any modification to the tree.')
    return Exists_Optimization_Result(node=exists_node,
                                      contains_quantifier=True,
                                      contains_rewritable_congruence=contains_optimizable_congruences,
                                      vars_to_rewrite_congruences_with=vars_to_optimize_congruences_with)


def _optimize_exists_tree_using_const_values_only(exists_node: AST_Quantifier) -> Tuple[ASTp_Node, bool]:
    is_exists_and_tree = isinstance(exists_node.child, AST_Connective) and exists_node.child.type == Connective_Type.AND
    if not is_exists_and_tree:
        return exists_node, True

    bound_vars = exists_node.bound_vars

    assert isinstance(exists_node.child, AST_Connective)
    and_node: AST_Connective = exists_node.child

    substitutions_to_make: List[Tuple[Var, int]] = []
    for subtree in and_node.children:
        if not isinstance(subtree, Relation):
            continue
        if not subtree.specifies_a_single_value_for_var():
            continue

        var = subtree.vars[0]
        if var not in bound_vars:
            continue

        coef = subtree.coefs[0]

        if (subtree.rhs % coef) != 0:
            return BoolLiteral(False), False

        implied_val = subtree.rhs // coef
        substitutions_to_make.append((var, implied_val))

    if not substitutions_to_make:
        return exists_node, True

    result: ASTp_Node = exists_node
    for var, value in substitutions_to_make:
        new_node = _substitute_var_with_value(result, var, value, Parent_Context_Var_Values())
        result = new_node

    if isinstance(result, AST_Quantifier) and not result.bound_vars:
        return result.child, True

    any_quantifier_lingers = len(bound_vars) > len(substitutions_to_make)
    return result, True


def _apply_bound_based_theory_reasoning(connective_type: Connective_Type,
                                        connective_children: Tuple[Tuple[ASTp_Node, bool], ...]) -> Tuple[Tuple[ASTp_Node, bool], ...]:
    """
    Params:
        - connective_children: Children of the connective that is being rewritten
                               with True iff they contain a quantifier.
    """
    if connective_type != Connective_Type.AND:
        return connective_children

    var_bounds: Dict[Var, Value_Interval] = defaultdict(Value_Interval)
    var_singular_congruences: Dict[Var, List[int]] = defaultdict(list)

    untouched_subtrees_mask: List[bool] = [True] * len(connective_children)

    for child_idx, child_info in enumerate(connective_children):
        child, does_child_contain_quantifier = child_info
        if isinstance(child, Congruence) and len(child.vars) == 1:
            var = child.vars[0]
            var_singular_congruences[var].append(child_idx)
            continue

        if not isinstance(child, Relation) or len(child.vars) > 1:
            continue

        var = child.vars[0]
        bounds = var_bounds[var]

        if child.is_hard_bound():
            bound_type, _, bound_value = get_hard_bound_semantics(child)
            if bound_type == Bound_Type.LOWER:
                bounds.try_strengthen_lower(bound_value)
            else:
                bounds.try_strengthen_upper(bound_value)
            untouched_subtrees_mask[child_idx] = False  # The atom has been consumed

        elif child.specifies_a_single_value_for_var():
            if child.is_unsat_eq():
                return ((BoolLiteral(False), False), )

            implied_val = child.rhs // child.coefs[0]
            bounds.try_strengthen_lower(implied_val)
            bounds.try_strengthen_upper(implied_val)
            untouched_subtrees_mask[child_idx] = False  # The atom has been consumed

        if bounds.lower_limit is None or bounds.upper_limit is None:
            continue

        if bounds.implies_contradiction():
            return ((BoolLiteral(False), False), )

    new_bounds = []
    for var, bound in var_bounds.items():
        is_fin = bound.lower_limit is not None and bound.upper_limit is not None
        var_congruences = var_singular_congruences[var]
        if is_fin and var_congruences:
            upper_bound: int = cast(int, bound.upper_limit)
            lower_bound: int = cast(int, bound.lower_limit)

            implied_var_values: Tuple[int, int] | None = None
            for congruence_idx in var_congruences:
                _congruence, _ = connective_children[congruence_idx]
                congruence = cast(Congruence, _congruence)
                if not congruence.is_normalized():
                    congruence = congruence.normalize()
                if not congruence:  # The congruence could not be normalized
                    continue

                # Congruence has the form 1*x = K (mod M)                <->  x = M*l + K
                # Bounds give restriction on x values: x_bound = [a, b]  <->  x >= a AND x <= b
                # Substitute x in the lower bound:                        ::  M*l + K >= a  <->  l >= (a - K) / M  <->  l >= math.ceil((a - K) / M)
                # Substitute x in the upper bound:                        ::  M*l + K <= b  <->  l <= (b - K) / M  <->  l <= math.floor((b - K) / M)
                smallest_solution = -(-(lower_bound - congruence.rhs) // congruence.modulus)  # ceil, exact for integers of any size
                largest_solution  = (upper_bound - congruence.rhs) // congruence.modulus      # floor

                # smallest_solution and largest_solution talk in terms of multiplies of M, turn it back into x
                smallest_solution = smallest_solution*congruence.modulus + congruence.rhs
                largest_solution  = largest_solution*congruence.modulus + congruence.rhs

                if not implied_var_values:
                    implied_var_values = (smallest_solution, largest_solution)
                else:
                    new_smallest_solution = max(smallest_solution, implied_var_values[0])
                    new_largest_solution = min(largest_solution, implied_var_values[1])
                    implied_var_values = (new_smallest_solution, new_largest_solution)
                logger.debug('Congruence solving for %s - implied var values: %s', var, implied_var_values)

            if not implied_var_values:
                new_bounds.extend((atom, False) for atom in bound.synthetize_atoms(var))
                continue

            if implied_var_values[0] > implied_var_values[1]:
                logger.info('Detected conflict via congruence solving on variable: %s', var)
                congruences = [connective_children[congruence_idx][0] for congruence_idx in var_congruences]
                logger.info('%s has finite range: [%d, %d] and the following congruences: %s', var, lower_bound, upper_bound, congruences)
                return ((BoolLiteral(False), False),)

            if implied_var_values[0] == implied_var_values[1]:
                logger.info('Detected only single possible value for variable %s via congruence solving', var)
                congruences = [connective_children[congruence_idx][0] for congruence_idx in var_congruences]
                logger.info('%s has finite range: [%d, %d] and the following congruences: %s', var, lower_bound, upper_bound, congruences)

                implied_value = implied_var_values[0]
                bound.lower_limit = implied_value
                bound.upper_limit = implied_value

        new_bounds.extend((bound, False) for bound in bound.synthetize_atoms(var))

    untouched_subtrees = (child for child_idx, child in enumerate(connective_children) if untouched_subtrees_mask[child_idx])
    result = tuple(new_bounds) + tuple(untouched_subtrees)
    return result


def _use_bool_laws_to_simplify_connective(connective_type: Connective_Type,
                                          subtrees: Tuple[Tuple[ASTp_Node, bool], ...]) -> Tuple[Tuple[ASTp_Node, bool], ...]:
    """
    Use idempotence and anihilation to simplify the connective subtrees.

    Params:
        - subtress - connective subtrees together with True iff they contain a quantifier

    Returns:
        - simplified subtrees (Bool literals are filtered out) with information about quantifier presense
    """
    if connective_type == Connective_Type.EQUIV:
        return subtrees

    if connective_type == Connective_Type.AND:
        neutral_elem = BoolLiteral(True)
        zero_elem    = BoolLiteral(False)
    else:
        neutral_elem = BoolLiteral(False)
        zero_elem    = BoolLiteral(True)

    if any(it[0] == zero_elem for it in subtrees):
        return (zero_elem, False),

    result = tuple(it for it in subtrees if it[0] != neutral_elem)
    if len(result) == 0:
        return ((neutral_elem, False), )
    return result


def _use_bool_laws_to_simplify_connective_plain(connective_type: Connective_Type,
                                                subtrees: Tuple[ASTp_Node, ...]) -> Tuple[ASTp_Node, ...]:
    """
    Use idempotence and anihilation to simplify the connective subtrees.
    """
    if connective_type == Connective_Type.EQUIV:
        return subtrees

    if connective_type == Connective_Type.AND:
        neutral_elem = BoolLiteral(True)
        zero_elem = BoolLiteral(False)
    else:
        neutral_elem = BoolLiteral(False)
        zero_elem = BoolLiteral(True)

    if zero_elem in subtrees:
        return (zero_elem,)

    result = tuple(it for it in subtrees if it != neutral_elem)
    if len(result) == 0:
        return (neutral_elem, )
    return result


def _shallow_flatten_connective(connective_type: Connective_Type,
                                connective_children: Tuple[Tuple[ASTp_Node, bool], ...]) -> Tuple[Tuple[ASTp_Node, bool], ...]:
    flattened_children: List[Tuple[ASTp_Node, bool]] = []

    for child, contains_quantifier in connective_children:
        if isinstance(child, AST_Connective) and child.type == connective_type:
            flattened_children.extend((ch, contains_quantifier) for ch in child.children)
        else:
            flattened_children.append((child, contains_quantifier))

    return tuple(flattened_children)


def _optimize_bottom_quantifiers(root: ASTp_Node) -> Tuple[ASTp_Node, bool]:
    match root:
        case Relation() | Congruence() | Var() | BoolLiteral():
            return root, False

        case AST_Connective():
            is_and_connective = root.type == Connective_Type.AND
            _optimized_subtrees = tuple(_optimize_bottom_quantifiers(child) for child in root.children)
            _optimized_subtrees = _shallow_flatten_connective(root.type, _optimized_subtrees)

            _optimized_subtrees = _apply_bound_based_theory_reasoning(root.type, _optimized_subtrees)
            _optimized_subtrees = _use_bool_laws_to_simplify_connective(root.type, _optimized_subtrees)

            optimized_subtrees = tuple(it[0] for it in _optimized_subtrees)
            any_quantifier_lingers: bool = functools.reduce(lambda a, b: a or b, (it[1] for it in _optimized_subtrees), False)
            if len(optimized_subtrees) == 1:
                return optimized_subtrees[0], any_quantifier_lingers

            new_node = AST_Connective(referenced_vars=root.referenced_vars,
                                      type=root.type,
                                      children=optimized_subtrees,
                                      variable_bounds=root.variable_bounds)

            return (new_node, any_quantifier_lingers or not is_and_connective)

        case AST_Negation():
            optimized_child, any_quantifier_present = _optimize_bottom_quantifiers(root.child)
            if optimized_child == BoolLiteral(True):
                return BoolLiteral(False), False
            elif optimized_child == BoolLiteral(False):
                return BoolLiteral(True), False
            elif isinstance(optimized_child, Relation) and optimized_child.predicate_symbol == '<=':
                return optimized_child.negate(), False

            new_node = AST_Negation(referenced_vars=root.referenced_vars, child=optimized_child)

            return new_node, any_quantifier_present

        case AST_Quantifier():
            # import pdb; pdb.set_trace()
            optimized_child, subtree_contains_quantifiers = _optimize_bottom_quantifiers(root.child)
            new_node = AST_Quantifier(referenced_vars=root.referenced_vars, bound_vars=root.bound_vars, child=optimized_child)

            if subtree_contains_quantifiers:
                # return new_node, subtree_contains_quantifiers
                new_node, this_quantifier_present = _optimize_exists_tree_using_const_values_only(new_node)
                return new_node, subtree_contains_quantifiers or this_quantifier_present

            exist_opt_result = _optimize_exists_tree(new_node)
            if exist_opt_result.contains_rewritable_congruence:
                exist_opt_result = optimize_congruences_on_unbound_vars(exist_opt_result.node, exist_opt_result)
            return exist_opt_result.node, exist_opt_result.contains_quantifier

        case _:
            raise NotImplementedError(f'Unhandled node while optimizing bottom quantifiers {root=}.')


def optimize_bottom_quantifiers(root: ASTp_Node) -> ASTp_Node:
    optimized_tree, _ = _optimize_bottom_quantifiers(root)
    return optimized_tree


def _interval_length(interval: Tuple[int, int]) -> int:
    return interval[1] - interval[0] + 1


def _strenghten_value_intervals(congruence: Congruence, value_intervals: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
    if not all(abs(coef) == 1 for coef in congruence.coefs):
        return value_intervals

    def interval_length(interval: Tuple[int, int]) -> int:
        return interval[1] - interval[0] + 1

    smaller_i, larger_i = value_intervals
    smaller_var_i, larger_var_i = 0, 1

    if interval_length(smaller_i) > interval_length(larger_i):
        smaller_i, larger_i = larger_i, smaller_i
        smaller_var_i, larger_var_i = larger_var_i, smaller_var_i

    if interval_length(smaller_i) >= congruence.modulus:
        return value_intervals # The intervals cannot be strenghtened

    def _solve_congruence_for_value(var_idx: int, var_value: int, value_interval: Tuple[int, int]):
        rhs = congruence.rhs - congruence.coefs[var_idx] * var_value
        rhs %= congruence.modulus
        if rhs < 0:
            rhs += congruence.modulus

        other_var_idx = 1 - var_idx
        other_var_coef = congruence.coefs[other_var_idx]

        if other_var_coef < 0:  # Multiply the congruence by -1
            rhs *= -1
            rhs += congruence.modulus

        # RHS is curently in [0, ... Modulus], shift it into the required interval
        shift_times = value_interval[0] // congruence.modulus  # floor, exact for integers of any size
        shifted_val = rhs + shift_times*congruence.modulus
        if shifted_val < value_interval[0]:
            shifted_val += congruence.modulus

        return shifted_val

    raise NotADirectoryError('Interval strenghtening is not implemented yet.')
    return []


MAX_LINEARIZATION_BRANCHES = 5
""" Upper bound on the number of disjuncts `_linearize_two_variable_congruence` produces for one congruence. """


def _attempt_congruence_linearization(congruence: Congruence,
                                      contexter: Parent_Context_Var_Values,
                                      monotonicity: Monotonicity_Info,
                                      monotonicity_eligible_vars: Optional[FrozenSet[Var]] = None) -> AST_Connective | BoolLiteral | None:
    """
    Replace `congruence` by the linear equations it has inside the box its variables' bounds describe,
    or return None when that is not possible.

    A variable is bounded either explicitly, by bounds asserted in an enclosing conjunction, or
    implicitly, by occurring monotonically so that a window of one modulus at the relevant bound
    contains a representative of every congruence class. The second argument is sound for the formula's
    *satisfiability* but narrows the variable's range, so it does not preserve the solution set over a
    variable the surrounding context also constrains.

    `monotonicity_eligible_vars` restricts the implicit argument to the variables listed in it; None
    places no restriction, which is the behaviour every caller had before the parameter existed. See
    `linearize_congruences`.
    """
    if len(congruence.vars) != 2:
        return None

    var_ranges: List[Tuple[int, int]] = []

    can_linearize = True

    for var in congruence.vars:
        # Check if the variable domain is explicitely finite
        var_bounds = contexter.lookup_asserted_values(var)
        is_fin = var_bounds.lower_limit is not None and var_bounds.upper_limit is not None
        if is_fin:
            assert var_bounds.lower_limit is not None
            assert var_bounds.upper_limit is not None

            var_ranges.append((var_bounds.lower_limit, var_bounds.upper_limit))
            continue

        if monotonicity_eligible_vars is not None and var not in monotonicity_eligible_vars:
            # The caller restricted the monotonicity argument and `var` is not covered: it is not bound
            # by a quantifier inside the formula this pass was handed, or the congruence sits under a
            # negation. Narrowing its range would then drop solutions the caller relies on.
            can_linearize = False
            break

        # Check if the variable domain is implicitly finite because of monotonicity
        var_monotonicity = monotonicity.seen_vars.get(var, Var_Monotonicity())

        if var_monotonicity.increasing and var_monotonicity.decreasing:
            can_linearize = False
            break

        is_c_best_from_below = var_bounds.upper_limit is not None and var_monotonicity.increasing
        if is_c_best_from_below:
            assert var_bounds.upper_limit is not None
            value_interval = (var_bounds.upper_limit-congruence.modulus+1, var_bounds.upper_limit)
            var_ranges.append(value_interval)
            continue

        is_c_best_from_above = var_bounds.lower_limit is not None and var_monotonicity.decreasing
        if is_c_best_from_above:
            assert var_bounds.lower_limit is not None
            value_interval = (var_bounds.lower_limit, var_bounds.lower_limit+congruence.modulus-1)
            var_ranges.append(value_interval)
            continue

        can_linearize = False
        break

    if not can_linearize:
        return None

    return _linearize_two_variable_congruence(congruence, var_ranges)


def _linearize_two_variable_congruence(congruence: Congruence, var_ranges: List[Tuple[int, int]]) -> AST_Connective | BoolLiteral | None:
    """
    Replace `a*x + b*y = r (mod M)` by a disjunction of linear equations, given finite ranges for `x`
    and `y` (in the order of `congruence.vars`), or return None.

    With `b` invertible modulo `M`, the congruence is equivalent to `y = c*x + d - k*M` for some
    integer `k`, where `c = -a * inv(b)` and `d = r * inv(b)` (mod M). The result has one disjunct per
    `k` for which `y` can fall into its range:

        (and (y_low <= c*x + d - k*M) (c*x + d - k*M <= y_high) (c*x - y = k*M - d))

    Every disjunct implies the congruence, and within the ranges the disjunction is equivalent to it.
    The range constraints are stated on `c*x` so that the disjunct also confines `y` to its range when
    that range comes from the monotonicity argument rather than from bounds present in the formula.

    The roles of the two variables are swapped if only the first coefficient is invertible.
    """
    modulus = congruence.modulus
    for x_idx, y_idx in ((0, 1), (1, 0)):
        y_coef = congruence.coefs[y_idx] % modulus
        if math.gcd(y_coef, modulus) == 1:
            break
    else:
        return None  # Neither coefficient is invertible, `y` is not a function of `x`

    x_var, y_var = congruence.vars[x_idx], congruence.vars[y_idx]
    x_low, x_high = var_ranges[x_idx]
    y_low, y_high = var_ranges[y_idx]

    if _interval_length((y_low, y_high)) > modulus:
        return None  # Several values of `y` per value of `x`; likely too many disjuncts

    y_coef_inverse = pow(y_coef, -1, modulus)
    x_coef = (-congruence.coefs[x_idx] * y_coef_inverse) % modulus
    if x_coef > modulus // 2:
        x_coef -= modulus  # The representative closest to 0 gives the fewest disjuncts
    offset = (congruence.rhs * y_coef_inverse) % modulus

    if x_coef == 0:
        return None  # The congruence does not relate the two variables

    x_term_low, x_term_high = sorted((x_coef * x_low, x_coef * x_high))
    first_k = -((y_high - x_term_low - offset) // modulus)   # ceil((x_term_low + offset - y_high) / M)
    last_k = (x_term_high + offset - y_low) // modulus       # floor((x_term_high + offset - y_low) / M)

    if last_k < first_k:
        return BoolLiteral(False)  # No value of `y` within its range satisfies the congruence
    if last_k - first_k + 1 > MAX_LINEARIZATION_BRANCHES:
        return None

    branches: List[AST_Connective] = []
    for k in range(first_k, last_k + 1):
        shift = offset - k * modulus  # y = x_coef*x + shift
        lower_bound = Relation(vars=[x_var], coefs=[-x_coef], rhs=shift - y_low, predicate_symbol='<=')
        upper_bound = Relation(vars=[x_var], coefs=[x_coef], rhs=y_high - shift, predicate_symbol='<=')
        if x_idx == 0:
            equation = Relation(vars=[x_var, y_var], coefs=[x_coef, -1], rhs=-shift, predicate_symbol='=')
        else:
            equation = Relation(vars=[y_var, x_var], coefs=[-1, x_coef], rhs=-shift, predicate_symbol='=')
        branches.append(AST_Connective(referenced_vars=tuple(), type=Connective_Type.AND,
                                       children=(lower_bound, upper_bound, equation)))

    return AST_Connective(referenced_vars=tuple(), type=Connective_Type.OR, children=tuple(branches))


def _linearize_congruences(root: ASTp_Node,
                           contexter: Parent_Context_Var_Values,
                           monotonicity: Monotonicity_Info,
                           monotonicity_eligible_vars: Optional[FrozenSet[Var]] = None) -> ASTp_Node:
    match root:
        case BoolLiteral() | Var() | Relation():
            return root
        case Congruence():
            linearized_congruence = _attempt_congruence_linearization(root, contexter, monotonicity,
                                                                     monotonicity_eligible_vars)
            if linearized_congruence is not None:
                return linearized_congruence
            return root

        case AST_Connective():
            def _linearize_isolated_subtree(subtree: ASTp_Node) -> ASTp_Node:
                contexter.enter_context()
                new_subtree = _linearize_congruences(subtree, contexter, monotonicity,
                                                     monotonicity_eligible_vars)
                contexter.exit_context()
                return new_subtree

            if root.type == Connective_Type.AND:
                # @Optimize: Assertions from other trees might be propagated into the current one, but are not at the moment
                contexter.enter_context()

                _insert_all_asserting_bounds_into_current_context(root, contexter)
                _optimized_subtrees = tuple(_linearize_congruences(subtree, contexter, monotonicity,
                                                                   monotonicity_eligible_vars)
                                            for subtree in root.children)

                contexter.exit_context()
            else:
                _optimized_subtrees = tuple(_linearize_isolated_subtree(subtree) for subtree in root.children)

            return root.replace_children(_optimized_subtrees)

        case AST_Negation():
            # Under a negation the monotonicity argument does not hold: the quantifier it reasons about
            # is universal from the outside, so no value of the variable may be picked "without loss of
            # generality". Every variable becomes ineligible for the rest of this subtree.
            eligible_vars_below = frozenset() if monotonicity_eligible_vars is not None else None
            contexter.enter_context()
            subtree = _linearize_congruences(root.child, contexter, monotonicity, eligible_vars_below)
            contexter.exit_context()
            return AST_Negation(referenced_vars=root.referenced_vars, child=subtree)

        case AST_Quantifier():
            eligible_vars_below = (monotonicity_eligible_vars | frozenset(root.bound_vars)
                                   if monotonicity_eligible_vars is not None else None)
            subtree = _linearize_congruences(root.child, contexter, monotonicity, eligible_vars_below)
            return AST_Quantifier(referenced_vars=root.referenced_vars, bound_vars=root.bound_vars, child=subtree)

        case _:
            raise NotImplementedError(f'Node {type(root)} not handled when doing congruence linearization.')


def linearize_congruences(root: ASTp_Node, restrict_monotonicity_to_bound_vars: bool = False) -> ASTp_Node:
    """
    Replace congruences by the linear equations they have inside the box their variables' bounds
    describe, wherever `_attempt_congruence_linearization` can do so.

    With `restrict_monotonicity_to_bound_vars`, a variable bounded only by the monotonicity argument is
    linearized only when it is bound by a quantifier inside `root` and the congruence does not sit under
    a negation. That argument narrows the variable's range, which preserves satisfiability but not the
    solution set, so it is admissible for a variable `root` quantifies away and not for one the caller's
    wider context also constrains. Callers that hand over a whole formula want the default, False;
    callers that hand over a fragment whose free variables are constrained elsewhere - such as
    `amaya.dpllt_automata.optimize_assertion_formula` - want True.
    """
    contexter = Parent_Context_Var_Values()

    monotonicity = Monotonicity_Info()
    _determine_monotonicity_of_variables(root, monotonicity, is_positive=True)

    eligible_vars = frozenset() if restrict_monotonicity_to_bound_vars else None
    opt = _linearize_congruences(root, contexter, monotonicity, eligible_vars)
    return opt
